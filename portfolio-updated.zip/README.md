# Mujib Ahmadzai | Front-End Developer Portfolio

A bilingual (English / Dari) personal portfolio built with React, Tailwind CSS, and Framer Motion.
It presents my skills, projects, education, and experience as an intern front-end developer,
with a working contact form, light and dark themes, and full right-to-left support.

## Features

- **Two languages:** English and Dari, with automatic RTL layout and a dedicated Dari font (Vazirmatn)
- **Light and dark themes** that follow the system setting and remember the visitor's choice
- **Responsive design**, built mobile-first
- **Page transitions:** a short loading screen on the first visit and a loader when switching pages
- **Working contact form** powered by [Web3Forms](https://web3forms.com), with validation, a spam honeypot, and a mailto fallback
- **SEO:** per-page titles and descriptions (both languages), Open Graph image, sitemap, robots.txt, and structured data
- **Accessibility:** skip link, focus management on page change, reduced-motion support, and ARIA live status messages
- **Easy to update:** all content lives in simple data files, with no page code to edit

## Tech stack

React 18 · Vite · Tailwind CSS · Framer Motion · React Router · Lucide icons · Font Awesome

## Getting started

```bash
pnpm install
pnpm dev        # http://localhost:3000
pnpm build      # production build in dist/
pnpm preview    # preview the production build
```

To test on a phone on the same network, run `pnpm dev --host`.

## Project structure

```
public/              Static files: CV, avatar images, OG image, icons, manifest
src/
  components/        Navbar, Footer, Hero, cards, loaders, contact form, SEO
  config/
    site.js          Name, links, CV, contact form, loading screen, site URL
    seo.js           Per-page titles and descriptions (EN + Dari)
  data/
    skills.js        Skills list
    projects.js      Projects list
    education.js     Education and training
    experience.js    Experience entries
  locales/           English and Dari translations
  pages/             Home, About, Skills, Projects, Experience, Education, Contact
```

## Updating content

| What | File |
| --- | --- |
| Name, links, email, CV file | `src/config/site.js` |
| Add or edit a skill | `src/data/skills.js` |
| Add or edit a project (image, live demo, GitHub link) | `src/data/projects.js` |
| Education and training | `src/data/education.js` |
| Page text and labels | `src/locales/translations.js` |
| Page titles and descriptions for search engines | `src/config/seo.js` |

Project screenshots go in `public/projects/` (WebP is recommended for small file size).

## Contact form

The form sends messages through Web3Forms. The access key is set in `src/config/site.js`
(`contactService.accessKey`). Web3Forms access keys are meant for front-end use and only allow
sending to the email address they were created for. After deploying, update the website URL in
your Web3Forms form settings.

## Deployment

The project is a static single-page app, so it works on Netlify, Vercel, GitHub Pages, and similar hosts.

1. Set the final address in `src/config/site.js`:
   ```js
   siteUrl: 'https://your-domain.com',
   ```
   (or pass the `SITE_URL` environment variable at build time). This enables canonical links,
   the social preview image, `sitemap.xml`, and structured data.
2. Run `pnpm build` and deploy the `dist/` folder.

Page refreshes on routes such as `/about` are handled by:

- `public/_redirects` for Netlify
- `vercel.json` for Vercel
- `404.html`, generated automatically at build time, for GitHub Pages

If the site is served from a sub-path (for example `https://user.github.io/portfolio/`), also set
`base` in `vite.config.js` and `basename` on the router.

## Author

**Mujib Ahmadzai**: Computer Science student and front-end developer
[GitHub](https://github.com/mujib-ah) · [LinkedIn](https://linkedin.com/in/mujib-ahmadzai)
