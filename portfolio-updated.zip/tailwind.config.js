export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        electric: {
          50: '#edf6ff',
          100: '#d7ecff',
          200: '#b6dcff',
          300: '#7fc3fe',
          400: '#3fa2fb',
          500: '#0e7fe7',
          600: '#0062cc',
          700: '#014ea8',
          800: '#07428b',
          900: '#0c3873',
          950: '#08234a',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        dari: ['Vazirmatn', 'Tahoma', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 0 25px -5px rgba(14, 127, 231, 0.45)',
        'glow-lg': '0 0 45px -10px rgba(14, 127, 231, 0.55)',
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        float: 'float 6s ease-in-out infinite',
        marquee: 'marquee 40s linear infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        marquee: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
      },
    },
  },
  plugins: [],
};
