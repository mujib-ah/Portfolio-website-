import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'node:path';
import siteConfig from './src/config/site.js';
import seoPages from './src/config/seo.js';

const siteUrl = (process.env.SITE_URL || siteConfig.siteUrl || '').replace(/\/$/, '');

function seoPlugin() {
  let outDir = 'dist';
  let root = process.cwd();
  return {
    name: 'portfolio-seo',
    configResolved(config) {
      outDir = config.build.outDir;
      root = config.root;
    },
    transformIndexHtml(html) {
      if (siteUrl) {
        return html
          .replace(/<!--SITE_URL_ONLY-->|<!--\/SITE_URL_ONLY-->/g, '')
          .replace(/__SITE_URL__/g, siteUrl);
      }
      return html.replace(/<!--SITE_URL_ONLY-->[\s\S]*?<!--\/SITE_URL_ONLY-->\s*/g, '');
    },
    generateBundle() {
      const robots = ['User-agent: *', 'Allow: /'];
      if (siteUrl) robots.push(`Sitemap: ${siteUrl}/sitemap.xml`);
      this.emitFile({ type: 'asset', fileName: 'robots.txt', source: robots.join('\n') + '\n' });

      if (siteUrl) {
        const today = new Date().toISOString().slice(0, 10);
        const urls = Object.entries(seoPages)
          .map(([route, page]) => {
            const loc = route === '/' ? `${siteUrl}/` : `${siteUrl}${route}`;
            return `  <url>\n    <loc>${loc}</loc>\n    <lastmod>${today}</lastmod>\n    <priority>${page.priority}</priority>\n  </url>`;
          })
          .join('\n');
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
        this.emitFile({ type: 'asset', fileName: 'sitemap.xml', source: xml });
      }
    },
    closeBundle() {
      const dist = path.resolve(root, outDir);
      const index = path.join(dist, 'index.html');
      if (fs.existsSync(index)) fs.copyFileSync(index, path.join(dist, '404.html'));
    },
  };
}

export default defineConfig({
  plugins: [react(), seoPlugin()],
  server: {
    port: 3000,
  },
});
