export const siteConfig = {
  siteUrl: '',

  name: 'Mujib Ahmadzai',
  nameDari: 'مجیب احمدزی',
  role: 'Intern Front-End Developer',
  roleDari: 'انترن فرانت‌اند دولوپر',
  location: 'Afghanistan',
  locationDari: 'افغانستان',

  avatar: '/avatar-800.webp',
  avatarSrcSet: '/avatar-480.webp 480w, /avatar-800.webp 800w',
  avatarSize: { width: 800, height: 1038 },
  avatarPosition: 'center 12%',

  cv: {
    enabled: true,
    file: '/Mujib_Ahmadzai_CV.pdf',
    downloadName: 'Mujib_Ahmadzai_CV.pdf',
    label: 'Download CV',
  },

  social: {
    github: 'https://github.com/mujib-ah',
    linkedin: 'https://linkedin.com/in/mujib-ahmadzai',
    email: 'webahmadzai@gmail.com',
  },

  contactService: {
    endpoint: 'https://api.web3forms.com/submit',
    service: 'web3forms',
    accessKey: '424aaca3-8a96-4d76-91e9-f4281ba23dd1',
  },

  loadingScreen: {
    enabled: true,
    displayName: 'MUJIB AHMADZAI',
    autoCloseMs: 1100,
  },
};

export default siteConfig;
