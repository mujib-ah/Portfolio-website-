const seoPages = {
  '/': {
    priority: '1.0',
    en: {
      title: 'Mujib Ahmadzai | Intern Front-End Developer Portfolio',
      description:
        'Mujib Ahmadzai, a computer science student and intern front-end developer building clean, responsive websites with React, Tailwind CSS, and JavaScript.',
    },
    da: {
      title: 'مجیب احمدزی | پورتفولیوی توسعه‌دهنده فرانت‌اند',
      description:
        'مجیب احمدزی، دانشجوی علوم کامپیوتر و توسعه‌دهنده فرانت‌اند، سازنده وب‌سایت‌های ریسپانسیو و مدرن با React، Tailwind CSS و JavaScript.',
    },
  },
  '/about': {
    priority: '0.8',
    en: {
      title: 'About Me | Mujib Ahmadzai',
      description:
        'Learn about Mujib Ahmadzai, a computer science student focused on front-end development, his background, goals, and what he is learning.',
    },
    da: {
      title: 'درباره من | مجیب احمدزی',
      description:
        'با مجیب احمدزی، دانشجوی علوم کامپیوتر با تمرکز بر توسعه فرانت‌اند، پیشینه، اهداف و مسیر یادگیری او آشنا شوید.',
    },
  },
  '/skills': {
    priority: '0.8',
    en: {
      title: 'Skills & Technologies | Mujib Ahmadzai',
      description:
        'Technologies Mujib Ahmadzai works with: HTML, CSS, JavaScript, React, Tailwind CSS, Bootstrap, Git and GitHub.',
    },
    da: {
      title: 'مهارت‌ها و تکنالوژی‌ها | مجیب احمدزی',
      description:
        'تکنالوژی‌هایی که مجیب احمدزی با آنها کار می‌کند: HTML، CSS، JavaScript، React، Tailwind CSS، Bootstrap، Git و GitHub.',
    },
  },
  '/projects': {
    priority: '0.9',
    en: {
      title: 'Projects | Mujib Ahmadzai',
      description:
        'Front-end projects by Mujib Ahmadzai, including the Ahmadzai Pharmacy landing page, with live demos and source code on GitHub.',
    },
    da: {
      title: 'پروژه‌ها | مجیب احمدزی',
      description:
        'پروژه‌های فرانت‌اند مجیب احمدزی از جمله صفحه معرفی داروخانه احمدزی، همراه با دموی زنده و کد منبع در GitHub.',
    },
  },
  '/experience': {
    priority: '0.6',
    en: {
      title: 'Experience | Mujib Ahmadzai',
      description:
        'Practical experience and hands-on learning of Mujib Ahmadzai in front-end web development.',
    },
    da: {
      title: 'تجربه‌ها | مجیب احمدزی',
      description: 'تجربه‌های عملی و یادگیری پروژه‌محور مجیب احمدزی در توسعه فرانت‌اند وب.',
    },
  },
  '/education': {
    priority: '0.6',
    en: {
      title: 'Education | Mujib Ahmadzai',
      description:
        'Education of Mujib Ahmadzai: computer science studies at Jahan University and front-end development training.',
    },
    da: {
      title: 'تحصیلات | مجیب احمدزی',
      description:
        'تحصیلات مجیب احمدزی: رشته علوم کامپیوتر در دانشگاه جهان و آموزش‌های توسعه فرانت‌اند.',
    },
  },
  '/contact': {
    priority: '0.7',
    en: {
      title: 'Contact | Mujib Ahmadzai',
      description:
        'Get in touch with Mujib Ahmadzai about internships, collaborations, or front-end projects. Send a message or connect on LinkedIn and GitHub.',
    },
    da: {
      title: 'تماس | مجیب احمدزی',
      description:
        'برای کارآموزی، همکاری یا پروژه‌های فرانت‌اند با مجیب احمدزی تماس بگیرید. پیام بفرستید یا در LinkedIn و GitHub وصل شوید.',
    },
  },
};

export const notFoundSeo = {
  en: { title: 'Page Not Found | Mujib Ahmadzai', description: 'The page you are looking for does not exist.' },
  da: { title: 'صفحه پیدا نشد | مجیب احمدزی', description: 'صفحه‌ای که دنبال آن هستید وجود ندارد.' },
};

export default seoPages;
