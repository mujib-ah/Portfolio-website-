export const projects = [
  {
    id: 'ahmadzai-pharmacy',
    name: 'Ahmadzai Pharmacy',
    nameDari: 'داروخانه احمدزی',
    category: 'Pharmacy Website',
    categoryDari: 'وب‌سایت داروخانه',
    description: {
      en: 'A modern, responsive pharmacy website built to showcase pharmaceutical products, store information, and customer-focused health services with clean navigation and accessible design.',
      da: 'یک وب‌سایت مدرن و ریسپانسیو برای داروخانه جهت معرفی محصولات دوایی، معلومات فروشگاه و خدمات صحی متمرکز بر مشتری با ناوبری تمیز و دسترسی آسان.',
    },
    technologies: ['HTML5', 'CSS3', 'JavaScript'],
    image: '/projects/ahmadzai-pharmacy.webp',
    imageAlt: 'Ahmadzai Pharmacy project preview',
    imageAltDari: 'پیش‌نمایش پروژه داروخانه احمدزی',
    liveUrl: 'https://mujib-ah.github.io/Ahmadzai-Pharmacy-Landing-Page-/',
    githubUrl: 'https://github.com/mujib-ah/Ahmadzai-Pharmacy-Landing-Page-',
    featured: true,
    year: '2026',
    highlights: {
      en: [
        'Responsive layout across mobile, tablet, and desktop',
        'Clean product and services presentation',
        'Interactive store information and contact access',
      ],
      da: [
        'چیدمان ریسپانسیو در موبایل، تبلت و کامپیوتر',
        'معرفی تمیز محصولات و خدمات',
        'دسترسی تعاملی به معلومات فروشگاه و تماس',
      ],
    },
  },
];

export default projects;
