export const skills = [
  {
    id: 'html5',
    name: 'HTML5',
    category: 'web',
    categoryKey: 'skills.categoryWeb',
    faIcon: 'fa-brands fa-html5',
    color: '#e34f26',
    description: {
      en: 'Semantic markup, accessibility, modern HTML APIs, SEO-friendly document structure.',
      da: 'نشانه‌گذاری معنایی، دسترسی‌پذیری، رابط‌های مدرن HTML و ساختار مناسب برای سئو.',
    },
  },
  {
    id: 'css3',
    name: 'CSS3',
    category: 'design',
    categoryKey: 'skills.categoryDesign',
    faIcon: 'fa-brands fa-css3-alt',
    color: '#1572b6',
    description: {
      en: 'Flexbox, Grid, animations, transitions, custom properties, and responsive design systems.',
      da: 'فلکسباکس، گرید، انیمیشن‌ها، ترنزیشن‌ها، متغیرهای سفارشی و سیستم‌های دیزاین ریسپانسیو.',
    },
  },
  {
    id: 'javascript',
    name: 'JavaScript (ES6+)',
    category: 'web',
    categoryKey: 'skills.categoryWeb',
    faIcon: 'fa-brands fa-js',
    color: '#f7df1e',
    textColor: '#1a1a1a',
    description: {
      en: 'Modern ES6+ syntax, async/await, DOM manipulation, fetch API, and modular code.',
      da: 'سینتکس مدرن ES6+، کار با همگام‌سازی، دستکاری DOM، کار با API و کدهای ماژولار.',
    },
  },
  {
    id: 'react',
    name: 'React.js',
    category: 'framework',
    categoryKey: 'skills.categoryFramework',
    faIcon: 'fa-brands fa-react',
    color: '#61dafb',
    description: {
      en: 'Component-based architecture, hooks, state management, and reusable UI systems.',
      da: 'معماری مبتنی بر مؤلفه، هوک‌ها، مدیریت وضعیت و سیستم‌های قابل استفاده مجدد رابط کاربری.',
    },
  },
  {
    id: 'responsive',
    name: 'Responsive Web Design',
    category: 'design',
    categoryKey: 'skills.categoryDesign',
    faIcon: 'fa-solid fa-mobile-screen-button',
    color: '#0e7fe7',
    description: {
      en: 'Mobile-first layouts, fluid grids, flexible media, and cross-device consistency.',
      da: 'چیدمان اولویت موبایل، گریدهای انعطاف‌پذیر، مدیا سازگار و یکدستی در تمام دستگاه‌ها.',
    },
  },
  {
    id: 'git',
    name: 'Git & GitHub',
    category: 'tools',
    categoryKey: 'skills.categoryTools',
    faIcon: 'fa-brands fa-github',
    color: '#f05032',
    description: {
      en: 'Version control, branching workflows, pull requests, collaboration, and repository management.',
      da: 'کنترول نسخه‌ها، شاخه‌بندی، درخواست ادغام، کار تیمی و مدیریت مخازن کد.',
    },
  },
  {
    id: 'font-awesome',
    name: 'Font Awesome',
    category: 'design',
    categoryKey: 'skills.categoryDesign',
    faIcon: 'fa-brands fa-font-awesome',
    color: '#538dd7',
    description: {
      en: 'Vector icon integration, visual hierarchy enhancement, and accessible iconography.',
      da: 'ادغام آیکون‌های وکتوری، بهبود سلسله‌مراتب بصری و آیکونوگرافی قابل دسترس.',
    },
  },
  {
    id: 'tailwind',
    name: 'Tailwind CSS',
    category: 'design',
    categoryKey: 'skills.categoryDesign',
    faIcon: 'fa-solid fa-wind',
    color: '#06b6d4',
    description: {
      en: 'Utility-first styling, rapid prototyping, custom design tokens, and dark-mode workflows.',
      da: 'استایل‌دهی مبتنی بر کاربرد، نمونه‌سازی سریع، تعریف تم‌های سفارشی و حالت تاریک.',
    },
  },
  {
    id: 'bootstrap',
    name: 'Bootstrap',
    category: 'framework',
    categoryKey: 'skills.categoryFramework',
    faIcon: 'fa-brands fa-bootstrap',
    color: '#7952b3',
    description: {
      en: 'Responsive grid system, ready-made components, and fast layout building for clean, consistent interfaces.',
      da: 'سیستم گرید ریسپانسیو، کامپوننت‌های آماده و ساخت سریع چیدمان برای رابط‌های تمیز و یکدست.',
    },
  },
];

export default skills;
