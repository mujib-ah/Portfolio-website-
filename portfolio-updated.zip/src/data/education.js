export const educations = [
  {
    id: 'jahan-university',
    category: 'university',
    institution: 'Jahan University',
    credentialType: 'degree',
    qualification: { en: "Bachelor's Degree", da: 'لیسانس' },
    fieldOfStudy: { en: 'Computer Science', da: 'علوم کمپیوتر' },
    duration: { en: '2023 – Present', da: '۲۰۲۳ – اکنون' },
    grade: { en: 'In Progress', da: 'در حال تحصیل' },
    ongoing: true,
    activities: {
      en: 'Member of the Computer Science Student Association. Participated in coding workshops and university technology events.',
      da: 'عضو انجمن محصلان علوم کمپیوتر هستم. در کارگاه‌های برنامه‌نویسی و برنامه‌های تکنالوژی پوهنتون اشتراک کرده‌ام.',
    },
    description: {
      en: 'Currently pursuing a Bachelor\'s degree in Computer Science at Jahan University. Building a strong foundation in programming, algorithms, data structures, and software development.',
      da: 'در حال حاضر در پوهنتون Jahan University دوره لیسانس علوم کمپیوتر را می‌گذرانم. در حال ایجاد بنیاد نیرومندی در برنامه‌نویسی، الگوریتم‌ها، ساختمان داده‌ها و توسعه نرم‌افزار هستم.',
    },
  },
  {
    id: 'upskill-learning-center',
    category: 'training',
    institution: 'UpSkill Learning Center',
    credentialType: 'certificate',
    qualification: { en: 'Front-End Development', da: 'توسعه فرانت‌اند' },
    duration: { en: '2025 – Present', da: '۲۰۲۵ – اکنون' },
    grade: { en: 'In Progress', da: 'در حال تکمیل' },
    ongoing: true,
    activities: {
      en: 'Completed hands-on projects using HTML, CSS, JavaScript, React, Tailwind CSS, and Bootstrap. Collaborated with peers on group coding exercises.',
      da: 'پروژه‌های عملی با HTML، CSS، JavaScript، React، Tailwind CSS و Bootstrap تکمیل کرده‌ام. در تمرین‌های گروهی برنامه‌نویسی با هم‌دوره‌ای‌ها همکاری کرده‌ام.',
    },
    description: {
      en: 'Currently enrolled in a Front-End Development program at UpSkill Learning Center. Learning HTML, CSS, JavaScript, React, Tailwind CSS, and Bootstrap through practical, hands-on projects.',
      da: 'در حال حاضر در برنامه توسعه فرانت‌اند در UpSkill Learning Center ثبت‌نام هستم. HTML، CSS، JavaScript، React، Tailwind CSS و Bootstrap را از طریق پروژه‌های عملی یاد می‌گیرم.',
    },
  },
  {
    id: 'said-noor-mohammad-shah-mina-high-school',
    category: 'highSchool',
    institution: 'Said Noor Mohammad Shah Mina High School',
    credentialType: 'qualification',
    qualification: { en: 'High School Diploma', da: 'سند فراغت لیسه' },
    fieldOfStudy: { en: 'General Studies', da: 'مطالعات عمومی' },
    duration: { en: '2010 – 2022', da: '۲۰۱۰ – ۲۰۲۲' },
    grade: { en: '92/100', da: '۹۲/۱۰۰' },
    ongoing: false,
    activities: {
      en: 'Participated in school sports and cultural events. Developed teamwork and communication skills.',
      da: 'در برنامه‌های ورزشی و فرهنگی مکتب اشتراک کردم. مهارت‌های کار گروهی و ارتباطی‌ام را تقویت کردم.',
    },
    description: {
      en: 'Completed my high school education with a general focus. Built a strong academic foundation that prepared me for university studies in Computer Science.',
      da: 'تحصیلات مکتب را با تمرکز بر مطالعات عمومی به پایان رساندم. بنیاد علمی نیرومندی ایجاد کردم که مرا برای تحصیلات پوهنتونی در علوم کمپیوتر آماده ساخت.',
    },
  },
];

export default educations;
