export const experiences = [
  {
    id: 'freelance-front-end',
    kind: 'freelance',
    category: {
      en: 'Freelance Experience',
      da: 'تجربه فریلنس',
    },
    title: {
      en: 'Freelance Front-End Developer & Web Designer',
      da: 'توسعه‌دهنده فرانت‌اند و طراح وب فریلنس',
    },
    employmentType: {
      en: 'Self-Employed',
      da: 'خویش‌فرما',
    },
    workType: {
      en: 'Freelance',
      da: 'فریلنس',
    },
    duration: {
      en: '2026 – Present',
      da: '۲۰۲۶ – اکنون',
    },
    description: {
      en: 'Working independently on designing and developing modern, responsive, and user-friendly websites for individuals. Focused on creating attractive user interfaces, improving user experience, and building functional websites using modern front-end technologies.',
      da: 'به‌صورت مستقل روی طراحی و توسعه وب‌سایت‌های مدرن، ریسپانسیو و کاربرپسند برای افراد کار می‌کنم. تمرکزم بر ایجاد رابط‌های کاربری جذاب، بهبود تجربه کاربری و ساخت وب‌سایت‌های کاربردی با استفاده از تکنالوژی‌های مدرن فرانت‌اند است.',
    },
    responsibilities: {
      en: [
        'Designing modern and professional website interfaces.',
        'Creating user-friendly UI/UX designs.',
        'Developing responsive websites for mobile, tablet, and desktop.',
        'Building websites using HTML5, CSS3, JavaScript, and React.js.',
        'Using Tailwind CSS for modern styling.',
        'Improving website usability and visual presentation.',
      ],
      da: [
        'طراحی رابط‌های مدرن و حرفه‌ای برای وب‌سایت‌ها.',
        'ایجاد دیزاین‌های UI/UX کاربرپسند.',
        'توسعه وب‌سایت‌های ریسپانسیو برای موبایل، تبلت و دسکتاپ.',
        'ساخت وب‌سایت‌ها با HTML5، CSS3، JavaScript و React.js.',
        'استفاده از Tailwind CSS برای استایل‌دهی مدرن.',
        'بهبود کاربردپذیری وب‌سایت و نمایش بصری آن.',
      ],
    },
    technologies: ['HTML5', 'CSS3', 'JavaScript', 'React.js', 'Tailwind CSS', 'Git & GitHub'],
  },
  {
    id: 'internship-and-junior-opportunities',
    kind: 'opportunities',
    category: {
      en: 'Current Career Status',
      da: 'وضعیت فعلی مسلکی',
    },
    title: {
      en: 'Seeking Internship & Junior Roles',
      da: 'در جستجوی کارآموزی و فرصت‌های جونیور',
    },
    status: {
      en: 'Open to Opportunities',
      da: 'آماده برای فرصت‌های کاری',
    },
    description: {
      en: 'Actively seeking Front-End Developer internship and junior-level opportunities to gain real-world experience, collaborate with professional development teams, improve my technical abilities, and contribute to meaningful web development projects.',
      da: 'به‌طور فعال به دنبال فرصت‌های کارآموزی توسعه فرانت‌اند و نقش‌های سطح جونیور هستم تا تجربه واقعی کسب کنم، با تیم‌های حرفه‌ای توسعه همکاری نمایم، توانایی‌های تخنیکی‌ام را بهبود بخشم و در پروژه‌های معنادار توسعه وب سهم بگیرم.',
    },
    currentStatusNote: {
      en: 'This card represents my current career status, not previous employment.',
      da: 'این کارت وضعیت فعلی مسلکی من را نشان می‌دهد، نه سابقه استخدام قبلی را.',
    },
  },
  {
    id: 'continuous-learning-and-growth',
    kind: 'growth',
    category: {
      en: 'Career Development',
      da: 'رشد مسلکی',
    },
    title: {
      en: 'Continuous Learning & Professional Growth',
      da: 'یادگیری مداوم و رشد حرفه‌ای',
    },
    description: {
      en: 'Continuously improving my Front-End Development skills through practical projects, independent learning, and hands-on experience. Focused on learning modern web technologies, improving problem-solving abilities, and developing the skills needed to become a professional Front-End Developer.',
      da: 'مهارت‌های توسعه فرانت‌اند خود را از طریق پروژه‌های عملی، یادگیری مستقل و تجربه دست‌اول پیوسته بهبود می‌دهم. تمرکزم بر یادگیری تکنالوژی‌های مدرن وب، تقویت توانایی حل مسئله و توسعه مهارت‌های لازم برای تبدیل‌شدن به یک توسعه‌دهنده حرفه‌ای فرانت‌اند است.',
    },
    focusAreas: {
      en: [
        'React.js Development',
        'Modern JavaScript',
        'UI/UX Design',
        'Responsive Web Design',
        'Clean and Maintainable Code',
        'Real-World Project Development',
      ],
      da: [
        'توسعه با React.js',
        'JavaScript مدرن',
        'دیزاین UI/UX',
        'دیزاین ریسپانسیو وب',
        'کد تمیز و قابل نگهداری',
        'توسعه پروژه‌های واقعی',
      ],
    },
  },
];

export default experiences;
