import { createContext, useContext, useEffect, useState, useMemo } from 'react';
import translations from '../locales/translations';

const LanguageContext = createContext(null);
const STORAGE_KEY = 'mujiport_lang';

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'en' || saved === 'da') return saved;
    } catch {}
    return 'en';
  });

  const isRTL = language === 'da';

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('lang', language);
    root.setAttribute('dir', isRTL ? 'rtl' : 'ltr');
    if (isRTL) {
      document.body.classList.add('font-dari');
      document.body.classList.remove('font-sans');
    } else {
      document.body.classList.add('font-sans');
      document.body.classList.remove('font-dari');
    }
    try {
      localStorage.setItem(STORAGE_KEY, language);
    } catch {}
  }, [language, isRTL]);

  const toggleLanguage = () => setLanguage((l) => (l === 'en' ? 'da' : 'en'));

  const t = useMemo(() => {
    return (path) => {
      const keys = path.split('.');
      let cur = translations[language];
      for (const k of keys) {
        if (cur && cur[k] !== undefined) cur = cur[k];
        else {
          let fb = translations.en;
          for (const fk of keys) fb = fb?.[fk];
          return fb ?? path;
        }
      }
      return cur;
    };
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
}

export default LanguageContext;
