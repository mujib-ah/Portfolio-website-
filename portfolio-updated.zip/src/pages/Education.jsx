import { Link } from 'react-router-dom';
import { GraduationCap, Calendar, BookOpen, ArrowRight, Award } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import SectionHeader from '../components/SectionHeader';
import { useLanguage } from '../context/LanguageContext';
import educations from '../data/education';
import { Reveal } from '../components/Motion';

const credentialKeys = {
  degree: 'degreeLabel',
  certificate: 'certificateLabel',
  qualification: 'qualificationLabel',
};

const categoryKeys = {
  university: 'categoryUniversity',
  training: 'categoryTraining',
  highSchool: 'categoryHighSchool',
};

const categoryStyles = {
  university: 'bg-electric-50 text-electric-700 dark:bg-electric-950/70 dark:text-electric-300',
  training: 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300',
  highSchool: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300',
};

export default function Education() {
  const { t, language, isRTL } = useLanguage();
  const reduceMotion = useReducedMotion();
  const railSide = isRTL ? { right: '1.125rem' } : { left: '1.125rem' };
  const markerSide = isRTL ? { right: '0.1875rem' } : { left: '0.1875rem' };

  return (
    <div className="py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow={t('common.tag')}
          title={t('education.title')}
          subtitle={t('education.subtitle')}
          hLevel={1}
        />

        <div className="relative mt-12 space-y-7 sm:space-y-9">
          <motion.div
            aria-hidden="true"
            className="absolute inset-y-5 w-px origin-top bg-gradient-to-b from-electric-400/70 via-electric-500/35 to-transparent"
            style={railSide}
            initial={reduceMotion ? false : { scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            viewport={{ once: true, amount: 0.1 }}
            transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          />

          {educations.map((edu, index) => {
            const qualification = typeof edu.qualification === 'string' ? edu.qualification : (edu.qualification?.[language] || edu.qualification?.en);
            const fieldOfStudy = typeof edu.fieldOfStudy === 'string' ? edu.fieldOfStudy : (edu.fieldOfStudy?.[language] || edu.fieldOfStudy?.en);
            const duration = edu.duration?.[language] || edu.duration?.en;
            const grade = edu.grade?.[language] || edu.grade?.en;
            const activities = edu.activities?.[language] || edu.activities?.en;
            const description = edu.description?.[language] || edu.description?.en;
            const credentialLabel = t(`education.${credentialKeys[edu.credentialType]}`);
            const categoryLabel = t(`education.${categoryKeys[edu.category]}`);
            const categoryStyle = categoryStyles[edu.category] || categoryStyles.university;

            return (
              <div className="relative" key={edu.id}>
                <span
                  aria-hidden="true"
                  className="absolute top-7 z-10 flex h-9 w-9 items-center justify-center rounded-full border-4 border-white bg-electric-600 text-white shadow-glow dark:border-slate-950"
                  style={markerSide}
                >
                  <GraduationCap className="h-4 w-4" />
                </span>

                <Reveal
                  as="article"
                  aria-labelledby={`${edu.id}-institution`}
                  delay={index * 0.07}
                  whileHover={reduceMotion ? undefined : { y: -4, scale: 1.003 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 28 }}
                  className="spotlight group rounded-3xl border border-slate-200/90 bg-white/90 p-5 shadow-[0_18px_55px_-42px_rgba(15,23,42,0.4)] backdrop-blur transition-[border-color,box-shadow] duration-300 hover:border-electric-300 hover:shadow-[0_24px_60px_-38px_rgba(14,127,231,0.35)] sm:p-7 lg:p-8 dark:border-slate-800 dark:bg-slate-900/90 dark:hover:border-electric-700"
                  style={{ marginInlineStart: '3.25rem' }}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className={`inline-flex items-center rounded-full px-3 py-1 text-[11px] font-bold tracking-wide ${categoryStyle}`}>
                      {categoryLabel}
                    </span>
                    {edu.ongoing && (
                      <span className="inline-flex items-center gap-2 rounded-full border border-electric-200 bg-electric-50/70 px-3 py-1 text-[11px] font-semibold text-electric-700 dark:border-electric-900 dark:bg-electric-950/50 dark:text-electric-300">
                        <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-electric-500" />
                        {t('education.inProgress')}
                      </span>
                    )}
                  </div>

                  <h2 id={`${edu.id}-institution`} className="mt-4 break-words text-xl font-extrabold leading-snug text-slate-900 transition-colors group-hover:text-electric-700 sm:text-2xl dark:text-white dark:group-hover:text-electric-300">
                    <bdi dir="auto">{edu.institution}</bdi>
                  </h2>

                  <p className="mt-2 text-sm font-bold text-electric-700 dark:text-electric-300">
                    <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">{credentialLabel}:</span>{' '}
                    <bdi dir="auto">{qualification}</bdi>
                  </p>

                  {edu.fieldOfStudy && (
                    <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{t('education.fieldOfStudy')}:</span>{' '}
                      <bdi dir="auto">{fieldOfStudy}</bdi>
                    </p>
                  )}

                  <div className="mt-6 grid gap-3 sm:grid-cols-2">
                    <div className="flex items-start gap-3 rounded-2xl border border-slate-200/80 bg-slate-50/80 p-4 dark:border-slate-800 dark:bg-slate-950/45">
                      <Calendar className="mt-0.5 h-4 w-4 shrink-0 text-electric-600 dark:text-electric-400" aria-hidden="true" />
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">{t('education.duration')}</p>
                        <p className="mt-1 text-sm font-semibold text-slate-800 dark:text-slate-200"><bdi dir="auto">{duration}</bdi></p>
                      </div>
                    </div>
                    <div className={`flex items-start gap-3 rounded-2xl border p-4 ${edu.ongoing ? 'border-electric-200/80 bg-electric-50/50 dark:border-electric-900/70 dark:bg-electric-950/25' : 'border-slate-200/80 bg-slate-50/80 dark:border-slate-800 dark:bg-slate-950/45'}`}>
                      <Award className={`mt-0.5 h-4 w-4 shrink-0 ${edu.ongoing ? 'text-electric-600 dark:text-electric-400' : 'text-slate-500 dark:text-slate-400'}`} aria-hidden="true" />
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">{t('education.grade')}</p>
                        <p className="mt-1 text-sm font-semibold text-slate-800 dark:text-slate-200"><bdi dir="auto">{grade}</bdi></p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 rounded-2xl border border-slate-100 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-950/35 sm:p-5">
                    <h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-slate-600 dark:text-slate-300">
                      <BookOpen className="h-4 w-4 text-electric-500" aria-hidden="true" />
                      {t('education.activities')}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{activities}</p>
                  </div>

                  <div className="mt-5">
                    <h3 className="text-xs font-bold uppercase tracking-wide text-slate-600 dark:text-slate-300">{t('education.description')}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{description}</p>
                  </div>
                </Reveal>
              </div>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-xl bg-electric-600 px-6 py-3 text-sm font-semibold text-white shadow-glow transition-all hover:-translate-y-0.5 hover:bg-electric-500 hover:shadow-glow-lg"
          >
            <span>{t('actions.contactMe')}</span>
            <ArrowRight className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
          </Link>
        </div>
      </div>
    </div>
  );
}
