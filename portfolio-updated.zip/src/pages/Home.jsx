import { Link } from 'react-router-dom';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, Code2, Globe2, Layers3, Sparkles } from 'lucide-react';
import HeroSection from '../components/HeroSection';
import CountUp from '../components/CountUp';
import TechMarquee from '../components/TechMarquee';
import SkillCard from '../components/SkillCard';
import HomeFeaturedProject from '../components/HomeFeaturedProject';
import SectionHeader from '../components/SectionHeader';
import { Stagger, Reveal } from '../components/Motion';
import { useLanguage } from '../context/LanguageContext';
import skills from '../data/skills';
import projects from '../data/projects';

export default function Home() {
  const { t, isRTL } = useLanguage();
  const reduceMotion = useReducedMotion();
  const featuredRecords = projects.filter((project) => project.featured);
  const featuredProjects = featuredRecords.length ? featuredRecords : projects.slice(0, 1);

  const stats = [
    { to: 1, suffix: '+', label: t('hero.statProjects'), icon: Layers3 },
    { to: skills.length, label: t('hero.statSkills'), icon: Code2 },
    { to: 2, label: t('hero.statMode'), icon: Globe2 },
  ];

  return (
    <div>
      <HeroSection />

      <TechMarquee />

      <section aria-label={t('home.statsLabel')} className="border-y border-slate-200/75 bg-white/55 py-7 backdrop-blur-sm sm:py-9 dark:border-slate-800/75 dark:bg-slate-950/45">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-5">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Reveal
                  key={stat.label}
                  as="article"
                  delay={index * 0.07}
                  whileHover={reduceMotion ? undefined : { y: -3 }}
                  className="spotlight group flex items-center gap-4 rounded-2xl border border-slate-200/75 bg-white/75 p-4 shadow-[0_14px_40px_-34px_rgba(15,23,42,0.35)] transition-[border-color,box-shadow] hover:border-electric-200 hover:shadow-electric-500/10 sm:justify-center sm:p-5 dark:border-slate-800/80 dark:bg-slate-900/70 dark:hover:border-electric-900"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-electric-50 text-electric-600 transition-transform duration-300 group-hover:scale-105 dark:bg-electric-950/70 dark:text-electric-300">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span className="text-start">
                    <bdi dir="ltr" className="block text-2xl font-extrabold tracking-tight text-slate-950 dark:text-white"><CountUp to={stat.to} suffix={stat.suffix} /></bdi>
                    <span className="mt-0.5 block text-xs font-semibold text-slate-500 sm:text-sm dark:text-slate-400">{stat.label}</span>
                  </span>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {featuredProjects.length > 0 && (
        <section className="relative overflow-hidden py-16 sm:py-20">
          <div aria-hidden="true" className="pointer-events-none absolute -top-24 start-1/2 -z-10 h-80 w-[min(90vw,54rem)] -translate-x-1/2 rounded-full bg-electric-400/10 blur-3xl dark:bg-electric-500/10" />
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <SectionHeader
              eyebrow={t('projects.featuredBadge')}
              title={t('projects.title')}
              subtitle={t('projects.subtitle')}
            />
            <div className={`mt-10 grid grid-cols-1 gap-6 sm:mt-12 ${featuredProjects.length > 1 ? 'xl:grid-cols-2' : ''}`}>
              {featuredProjects.map((project) => <HomeFeaturedProject key={project.id} project={project} />)}
            </div>
          </div>
        </section>
      )}

      <section className="border-t border-slate-200/75 bg-slate-100/45 py-16 sm:py-20 dark:border-slate-800/75 dark:bg-slate-950/25">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow={t('common.tag')}
            title={t('skills.title')}
            subtitle={t('skills.subtitle')}
          />
          <Stagger className="mt-10 grid grid-cols-1 gap-5 sm:mt-12 sm:grid-cols-2 lg:grid-cols-4">
            {skills.map((skill) => (
              <SkillCard key={skill.id} skill={skill} />
            ))}
          </Stagger>
          <div className="mt-9 text-center">
            <motion.div whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.98 }}>
              <Link
                to="/skills"
                className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-xs font-semibold text-slate-800 shadow-sm transition-colors hover:border-electric-400 hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 focus-visible:ring-offset-2 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:border-electric-500 dark:hover:bg-slate-800"
              >
                <span>{t('actions.exploreSkills')}</span>
                <ArrowRight className={`h-3.5 w-3.5 ${isRTL ? 'rotate-180' : ''}`} aria-hidden="true" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      <motion.section
        initial={reduceMotion ? false : { opacity: 0, y: 14 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: reduceMotion ? 0.15 : 0.52, ease: [0.22, 1, 0.36, 1] }}
        className="relative overflow-hidden py-16 sm:py-20"
      >
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-gradient-to-r from-electric-500/10 via-sky-500/10 to-indigo-500/10 blur-2xl" />
        <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-electric-100 px-3 py-1 text-xs font-semibold text-electric-800 dark:bg-electric-950/70 dark:text-electric-300">
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            {t('hero.badge')}
          </span>
          <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl dark:text-white">{t('actions.getInTouch')}</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-slate-600 sm:text-base dark:text-slate-400">{t('contact.subtitle')}</p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <motion.div whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.98 }}>
              <Link to="/contact" className="btn-shine inline-flex min-h-11 items-center gap-2 rounded-xl bg-electric-600 px-6 py-3 text-sm font-semibold text-white shadow-glow transition-all hover:bg-electric-500 hover:shadow-glow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 focus-visible:ring-offset-2">
                <span>{t('actions.contactMe')}</span>
                <ArrowRight className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} aria-hidden="true" />
              </Link>
            </motion.div>
            <motion.div whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.98 }}>
              <Link to="/about" className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-800 transition-colors hover:border-electric-300 hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 focus-visible:ring-offset-2 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:border-electric-700 dark:hover:bg-slate-800">
                {t('actions.learnMore')}
              </Link>
            </motion.div>
          </div>
        </div>
      </motion.section>

    </div>
  );
}
