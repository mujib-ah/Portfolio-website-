import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function NotFound() {
  const { t } = useLanguage();

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center px-4 py-24 text-center">
      <p className="text-8xl font-extrabold text-electric-500/30 dark:text-electric-500/20 select-none">
        404
      </p>
      <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-white">
        {t('notFound.title')}
      </h1>
      <p className="mt-2 max-w-md text-sm text-slate-600 dark:text-slate-400">
        {t('notFound.text')}
      </p>
      <Link
        to="/"
        className="mt-8 inline-flex items-center gap-2 rounded-xl bg-electric-600 px-5 py-2.5 text-xs font-semibold text-white shadow-glow hover:bg-electric-500"
      >
        <Home className="h-4 w-4" />
        {t('notFound.home')}
      </Link>
    </div>
  );
}
