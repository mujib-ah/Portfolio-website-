import { useState } from 'react';
import { Mail, MapPin, Copy, Check, Clock, ExternalLink } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import ContactForm from '../components/ContactForm';
import { Reveal } from '../components/Motion';
import { useLanguage } from '../context/LanguageContext';
import siteConfig from '../config/site';

export default function Contact() {
  const { t, language } = useLanguage();
  const [copied, setCopied] = useState(false);
  const location = language === 'da' ? siteConfig.locationDari : siteConfig.location;

  const copyEmail = async () => {
    try {
      await navigator.clipboard?.writeText(siteConfig.social.email);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const cardClass = 'spotlight flex items-center justify-between rounded-2xl border border-slate-200/90 bg-white/90 p-4 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-electric-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900/90 dark:hover:border-electric-800';
  const iconClass = 'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-electric-50 text-electric-600 dark:bg-electric-950/70 dark:text-electric-400';
  const labelClass = 'text-[11px] font-semibold uppercase tracking-wider text-slate-400';
  const valueClass = 'text-xs font-semibold text-slate-900 dark:text-white';

  return (
    <div className="py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <SectionHeader eyebrow={t('common.tag')} title={t('contact.title')} subtitle={t('contact.subtitle')} hLevel={1} />

        <div className="mt-14 grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12">
          <div className="space-y-6 lg:col-span-5">
            <Reveal>
              <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">{t('contact.infoTitle')}</h2>
              <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{t('contact.infoText')}</p>
            </Reveal>

            <div className="space-y-3">
              <Reveal className={cardClass} whileHover={{ y: -2 }}>
                <div className="flex min-w-0 items-center gap-3">
                  <div className={iconClass}><Mail className="h-5 w-5" /></div>
                  <div className="min-w-0">
                    <p className={labelClass}>{t('contact.emailLabel')}</p>
                    <a href={`mailto:${siteConfig.social.email}`} className="block truncate text-xs font-semibold text-slate-900 transition-colors hover:text-electric-600 dark:text-white dark:hover:text-electric-400">{siteConfig.social.email}</a>
                  </div>
                </div>
                <button type="button" onClick={copyEmail} className="ms-2 shrink-0 rounded-lg p-2 text-slate-400 transition-all hover:bg-electric-50 hover:text-electric-600 dark:hover:bg-slate-800 dark:hover:text-electric-300" title={t('actions.copyEmail')} aria-label={t('actions.copyEmail')}>
                  {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
                </button>
              </Reveal>

              <Reveal as="a" delay={0.04} whileHover={{ y: -2 }} href={siteConfig.social.linkedin} target="_blank" rel="noreferrer" className={cardClass}>
                <div className="flex items-center gap-3"><div className={iconClass}><i className="fa-brands fa-linkedin text-lg" aria-hidden="true" /></div><div><p className={labelClass}>{t('contact.linkedinLabel')}</p><p className={valueClass}>/in/mujib-ahmadzai</p></div></div>
                <ExternalLink className="h-4 w-4 text-slate-400" />
              </Reveal>

              <Reveal as="a" delay={0.08} whileHover={{ y: -2 }} href={siteConfig.social.github} target="_blank" rel="noreferrer" className={cardClass}>
                <div className="flex items-center gap-3"><div className={iconClass}><i className="fa-brands fa-github text-lg" aria-hidden="true" /></div><div><p className={labelClass}>{t('contact.githubLabel')}</p><p className={valueClass}>@mujib-ah</p></div></div>
                <ExternalLink className="h-4 w-4 text-slate-400" />
              </Reveal>

              <Reveal delay={0.12} whileHover={{ y: -2 }} className={cardClass}>
                <div className="flex items-center gap-3"><div className={iconClass}><MapPin className="h-5 w-5" /></div><div><p className={labelClass}>{t('contact.locationLabel')}</p><p className={valueClass}>{location}</p></div></div>
              </Reveal>
            </div>

            <Reveal delay={0.16} className="rounded-2xl border border-electric-200 bg-gradient-to-r from-electric-50/90 to-sky-50/70 p-4 text-xs text-slate-700 shadow-sm dark:border-electric-900/60 dark:from-electric-950/40 dark:to-sky-950/30 dark:text-slate-300">
              <div className="flex items-center gap-2 font-semibold text-electric-700 dark:text-electric-300"><Clock className="h-4 w-4" /><span>{t('contact.responseTimeLabel')}</span></div>
              <p className="mt-1">{t('contact.responseTimeText')}</p>
            </Reveal>
          </div>

          <div className="lg:col-span-7"><ContactForm /></div>
        </div>
      </div>
    </div>
  );
}
