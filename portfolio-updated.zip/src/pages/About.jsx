import { Sparkles, Compass, Heart, GraduationCap, Target, Award, CheckCircle2 } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import { Reveal, Stagger } from '../components/Motion';
import { useLanguage } from '../context/LanguageContext';

export default function About() {
  const { t } = useLanguage();
  const learning = t('about.learningItems') || [];
  const coreValues = t('about.coreValues') || [];

  const cardClass = 'rounded-3xl border border-slate-200/90 bg-white/90 p-7 shadow-[0_18px_55px_-42px_rgba(15,23,42,0.45)] backdrop-blur-sm sm:p-9 dark:border-slate-800 dark:bg-slate-900/85';
  const iconClass = 'flex h-10 w-10 items-center justify-center rounded-xl bg-electric-50 text-electric-600 dark:bg-electric-950/70 dark:text-electric-400';
  const titleClass = 'text-xl font-bold tracking-tight text-slate-900 dark:text-white';
  const bodyClass = 'mt-4 text-sm leading-relaxed text-slate-600 sm:text-base dark:text-slate-300';

  return (
    <div className="py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionHeader eyebrow={t('common.tag')} title={t('about.title')} subtitle={t('about.subtitle')} hLevel={1} />

        <div className="mt-10 grid grid-cols-1 gap-5 sm:mt-12 lg:grid-cols-2">
          <Reveal as="section" className={cardClass}>
            <div className="flex items-center gap-3"><div className={iconClass}><Sparkles className="h-5 w-5" /></div><h2 className={titleClass}>{t('about.introTitle')}</h2></div>
            <p className={bodyClass}>{t('about.introText')}</p>
          </Reveal>

          <Reveal as="section" delay={0.04} className={cardClass}>
            <div className="flex items-center gap-3"><div className={iconClass}><Compass className="h-5 w-5" /></div><h2 className={titleClass}>{t('about.journeyTitle')}</h2></div>
            <p className={bodyClass}>{t('about.journeyText')}</p>
          </Reveal>

          <Reveal as="section" delay={0.04} className={cardClass}>
            <div className="flex items-center gap-3"><div className={iconClass}><Heart className="h-5 w-5" /></div><h2 className={titleClass}>{t('about.passionTitle')}</h2></div>
            <p className={bodyClass}>{t('about.passionText')}</p>
          </Reveal>

          <Reveal as="section" delay={0.04} className={cardClass}>
            <div className="flex items-center gap-3"><div className={iconClass}><GraduationCap className="h-5 w-5" /></div><h2 className={titleClass}>{t('about.learningTitle')}</h2></div>
            <ul className="mt-5 space-y-3">{Array.isArray(learning) && learning.map((item, index) => <li key={index} className="flex items-start gap-3 text-sm text-slate-600 dark:text-slate-300"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-electric-500" /><span>{item}</span></li>)}</ul>
          </Reveal>

          <Reveal as="section" delay={0.04} className={`${cardClass} lg:col-span-2`}>
            <div className="flex items-center gap-3"><div className={iconClass}><Target className="h-5 w-5" /></div><h2 className={titleClass}>{t('about.goalsTitle')}</h2></div>
            <p className={bodyClass}>{t('about.goalsText')}</p>
          </Reveal>

          <section className="lg:col-span-2">
            <Reveal><h2 className="text-center text-xl font-bold tracking-tight text-slate-900 dark:text-white">{t('about.coreValuesTitle')}</h2></Reveal>
            <Stagger className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-3">
              {Array.isArray(coreValues) && coreValues.map((value, index) => (
                <Reveal key={index} as="article" delay={index * 0.06} className="spotlight rounded-2xl border border-slate-200/90 bg-white/90 p-6 shadow-sm transition-colors dark:border-slate-800 dark:bg-slate-900/85">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric-600 text-xs font-bold text-white shadow-md shadow-electric-600/20">0{index + 1}</div>
                  <h3 className="mt-4 text-base font-bold text-slate-900 dark:text-white">{value.title}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">{value.desc}</p>
                </Reveal>
              ))}
            </Stagger>
          </section>

          <Reveal className="rounded-2xl border border-dashed border-slate-300 bg-slate-50/80 p-5 text-center text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-950/50 dark:text-slate-400 lg:col-span-2">
            <Award className="mx-auto mb-1 h-5 w-5 text-electric-500" />
            <p className="font-semibold text-slate-700 dark:text-slate-300">{t('about.placeholderTitle')}</p>
            <p className="mt-1">{t('about.placeholderText')}</p>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
