import { useState, useMemo } from 'react';
import SectionHeader from '../components/SectionHeader';
import SkillCard from '../components/SkillCard';
import { useLanguage } from '../context/LanguageContext';
import skills from '../data/skills';
import { Reveal, Stagger } from '../components/Motion';

export default function Skills() {
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', labelKey: 'projects.filterAll' },
    { id: 'web', labelKey: 'skills.categoryWeb' },
    { id: 'framework', labelKey: 'skills.categoryFramework' },
    { id: 'tools', labelKey: 'skills.categoryTools' },
    { id: 'design', labelKey: 'skills.categoryDesign' },
  ];

  const filtered = useMemo(() => {
    if (activeCategory === 'all') return skills;
    return skills.filter((s) => s.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className="py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow={t('skills.coreTitle')}
          title={t('skills.title')}
          subtitle={t('skills.subtitle')}
          hLevel={1}
        />

        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {categories.map((c) => {
            const active = activeCategory === c.id;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setActiveCategory(c.id)}
                className={`rounded-xl px-4 py-2 text-xs font-semibold transition-all duration-200 hover:-translate-y-0.5 ${
                  active
                    ? 'bg-electric-600 text-white shadow-glow'
                    : 'border border-slate-200 bg-white text-slate-600 hover:border-electric-400 hover:text-electric-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400 dark:hover:border-electric-500'
                }`}
              >
                {t(c.labelKey)}
              </button>
            );
          })}
        </div>

        <Stagger className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {filtered.map((skill) => <SkillCard key={skill.id} skill={skill} />)}
        </Stagger>

        <div className="mx-auto mt-14 max-w-3xl">
          <Reveal className="rounded-2xl border border-slate-200 bg-white/85 p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/90">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">
              {t('skills.notesTitle')}
            </h2>
            <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              {t('skills.notesText')}
            </p>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
