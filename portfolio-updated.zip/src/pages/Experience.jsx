import { Link } from 'react-router-dom';
import {
  ArrowRight,
  BookOpen,
  Briefcase,
  Calendar,
  Check,
  Code2,
  Info,
  Search,
} from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import SectionHeader from '../components/SectionHeader';
import { useLanguage } from '../context/LanguageContext';
import experiences from '../data/experience';
import { Reveal } from '../components/Motion';

const cardIcons = {
  freelance: Briefcase,
  opportunities: Search,
  growth: BookOpen,
};

const cardStyles = {
  freelance: {
    icon: 'bg-electric-600 text-white shadow-glow',
    border: 'border-electric-200/90 dark:border-electric-900/70',
    badge: 'bg-electric-50 text-electric-700 dark:bg-electric-950/60 dark:text-electric-300',
  },
  opportunities: {
    icon: 'bg-emerald-600 text-white shadow-[0_0_24px_-8px_rgba(16,185,129,0.75)]',
    border: 'border-emerald-200/80 dark:border-emerald-900/60',
    badge: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300',
  },
  growth: {
    icon: 'bg-sky-600 text-white shadow-[0_0_24px_-8px_rgba(14,165,233,0.65)]',
    border: 'border-sky-200/80 dark:border-sky-900/60',
    badge: 'bg-sky-50 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300',
  },
};

export default function Experience() {
  const { t, language, isRTL } = useLanguage();
  const reduceMotion = useReducedMotion();
  const valueFor = (value) => (typeof value === 'string' ? value : (value?.[language] || value?.en));

  return (
    <div className="py-14 sm:py-18">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow={t('common.tag')}
          title={t('experience.title')}
          subtitle={t('experience.subtitle')}
          hLevel={1}
        />

        <div className="mt-10 grid gap-5 sm:mt-12 sm:gap-6 lg:grid-cols-2">
          {experiences.map((experience, index) => {
            const Icon = cardIcons[experience.kind] || Briefcase;
            const styles = cardStyles[experience.kind] || cardStyles.freelance;
            const title = valueFor(experience.title);
            const category = valueFor(experience.category);
            const description = valueFor(experience.description);
            const isFeatured = experience.kind === 'freelance';
            const isOpportunities = experience.kind === 'opportunities';
            const responsibilities = experience.responsibilities?.[language] || experience.responsibilities?.en || [];
            const focusAreas = experience.focusAreas?.[language] || experience.focusAreas?.en || [];

            return (
              <Reveal
                as="article"
                key={experience.id}
                aria-labelledby={`${experience.id}-title`}
                delay={index * 0.1}
                whileHover={reduceMotion ? undefined : { y: -5, scale: 1.004 }}
                transition={{ type: 'spring', stiffness: 280, damping: 25 }}
                className={`group relative overflow-hidden rounded-3xl border bg-white/90 p-5 shadow-[0_20px_60px_-42px_rgba(15,23,42,0.45)] backdrop-blur transition-[border-color,box-shadow] duration-300 sm:p-7 dark:bg-slate-900/90 ${styles.border} ${isFeatured ? 'lg:col-span-2 lg:p-8' : ''} ${isOpportunities ? 'hover:border-emerald-300 hover:shadow-emerald-500/10 dark:hover:border-emerald-800' : 'hover:border-electric-300 hover:shadow-electric-500/10 dark:hover:border-electric-700'}`}
              >
                {isFeatured && (
                  <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-electric-500 via-sky-400 to-electric-600" />
                )}

                <div className={`flex items-start gap-4 ${isFeatured ? 'sm:gap-5' : ''}`}>
                  <motion.div
                    className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${styles.icon}`}
                    whileHover={reduceMotion ? undefined : { rotate: -5, scale: 1.07 }}
                    transition={{ type: 'spring', stiffness: 350, damping: 20 }}
                  >
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </motion.div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className={`inline-flex rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] ${styles.badge}`}>
                        {category}
                      </span>
                      {isOpportunities && (
                        <span className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[11px] font-bold text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/50 dark:text-emerald-300">
                          <motion.span
                            aria-hidden="true"
                            className="h-2 w-2 rounded-full bg-emerald-500"
                            animate={reduceMotion ? undefined : { scale: [1, 1.22, 1], opacity: [1, 0.72, 1] }}
                            transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                          />
                          <span>{t('experience.status')}:</span>
                          <bdi dir="auto">{valueFor(experience.status)}</bdi>
                        </span>
                      )}
                    </div>

                    {isFeatured && (
                      <p className="mt-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400 dark:text-slate-500">
                        {t('experience.jobTitle')}
                      </p>
                    )}
                    <h2 id={`${experience.id}-title`} className={`${isFeatured ? 'mt-1 text-xl sm:text-2xl' : 'mt-3 text-lg sm:text-xl'} font-extrabold leading-snug text-slate-900 transition-colors group-hover:text-electric-700 dark:text-white dark:group-hover:text-electric-300`}>
                      {title}
                    </h2>

                    {isFeatured && (
                      <div className="mt-4 flex flex-wrap gap-2">
                        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-300">
                          <span className="font-semibold text-slate-400 dark:text-slate-500">{t('experience.employmentType')}:</span>
                          {valueFor(experience.employmentType)}
                        </span>
                        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-300">
                          <span className="font-semibold text-slate-400 dark:text-slate-500">{t('experience.workType')}:</span>
                          {valueFor(experience.workType)}
                        </span>
                        <span className="inline-flex items-center gap-1.5 rounded-full border border-electric-200 bg-electric-50/70 px-3 py-1.5 text-xs font-semibold text-electric-700 dark:border-electric-900 dark:bg-electric-950/40 dark:text-electric-300">
                          <Calendar className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>{t('experience.duration')}:</span>
                          <bdi dir="auto">{valueFor(experience.duration)}</bdi>
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <p className={`text-sm leading-relaxed text-slate-600 dark:text-slate-400 ${isFeatured ? 'mt-5 sm:mt-6 sm:text-[15px]' : 'mt-5'}`}>
                  {description}
                </p>

                {isFeatured && (
                  <div className="mt-7 grid gap-7 border-t border-slate-100 pt-6 dark:border-slate-800 xl:grid-cols-[1.15fr_0.85fr]">
                    <section aria-labelledby={`${experience.id}-responsibilities`}>
                      <h3 id={`${experience.id}-responsibilities`} className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-700 dark:text-slate-300">
                        <Check className="h-4 w-4 text-electric-500" aria-hidden="true" />
                        {t('experience.responsibilities')}
                      </h3>
                      <ul className="mt-4 grid gap-x-5 gap-y-3 sm:grid-cols-2">
                        {responsibilities.map((responsibility, responsibilityIndex) => (
                          <motion.li
                            key={`${experience.id}-responsibility-${responsibilityIndex}`}
                            className="flex items-start gap-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400"
                            whileHover={reduceMotion ? undefined : { x: isRTL ? -2 : 2 }}
                            transition={{ duration: 0.18 }}
                          >
                            <Check className="mt-0.5 h-4 w-4 shrink-0 text-electric-500" aria-hidden="true" />
                            <span>{responsibility}</span>
                          </motion.li>
                        ))}
                      </ul>
                    </section>

                    <section aria-labelledby={`${experience.id}-technologies`}>
                      <h3 id={`${experience.id}-technologies`} className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-700 dark:text-slate-300">
                        <Code2 className="h-4 w-4 text-electric-500" aria-hidden="true" />
                        {t('experience.technologies')}
                      </h3>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {experience.technologies.map((technology) => (
                          <motion.span
                            key={technology}
                            className="rounded-xl border border-electric-100 bg-electric-50/80 px-3 py-2 text-xs font-semibold text-electric-800 dark:border-electric-900/70 dark:bg-electric-950/35 dark:text-electric-200"
                            whileHover={reduceMotion ? undefined : { y: -2, scale: 1.035 }}
                            transition={{ duration: 0.18 }}
                          >
                            <bdi dir="auto">{technology}</bdi>
                          </motion.span>
                        ))}
                      </div>
                    </section>
                  </div>
                )}

                {isOpportunities && (
                  <div className="mt-5 rounded-2xl border border-emerald-100 bg-emerald-50/60 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/25">
                    <div className="flex items-start gap-3">
                      <Info className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700 dark:text-emerald-300" aria-hidden="true" />
                      <p className="text-xs font-medium leading-relaxed text-emerald-900 dark:text-emerald-200">
                        {valueFor(experience.currentStatusNote)}
                      </p>
                    </div>
                  </div>
                )}

                {experience.focusAreas && (
                  <section className="mt-6 border-t border-slate-100 pt-5 dark:border-slate-800" aria-labelledby={`${experience.id}-focus-areas`}>
                    <h3 id={`${experience.id}-focus-areas`} className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-slate-700 dark:text-slate-300">
                      <Code2 className="h-4 w-4 text-sky-500" aria-hidden="true" />
                      {t('experience.focusAreas')}
                    </h3>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {focusAreas.map((focusArea) => (
                        <motion.span
                          key={focusArea}
                          className="rounded-xl border border-sky-100 bg-sky-50/80 px-3 py-2 text-xs font-medium text-slate-700 dark:border-sky-900/60 dark:bg-sky-950/30 dark:text-slate-200"
                          whileHover={reduceMotion ? undefined : { y: -2 }}
                          transition={{ duration: 0.18 }}
                        >
                          {focusArea}
                        </motion.span>
                      ))}
                    </div>
                  </section>
                )}
              </Reveal>
            );
          })}
        </div>

        <div className="mt-10 text-center sm:mt-12">
          <motion.div whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.98 }}>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-xl bg-electric-600 px-6 py-3 text-sm font-semibold text-white shadow-glow transition-all duration-200 hover:bg-electric-500 hover:shadow-glow-lg"
            >
              <span>{t('actions.contactMe')}</span>
              <ArrowRight className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
