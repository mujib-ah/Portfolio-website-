import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import ProjectCard from '../components/ProjectCard';
import { useLanguage } from '../context/LanguageContext';
import projects from '../data/projects';

export default function Projects() {
  const { t, isRTL } = useLanguage();

  return (
    <div className="py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <SectionHeader
          eyebrow={t('common.tag')}
          title={t('projects.title')}
          subtitle={t('projects.subtitle')}
          hLevel={1}
        />

        <div className={`mx-auto mt-12 grid grid-cols-1 gap-8 ${projects.length > 1 ? 'md:grid-cols-2' : 'max-w-5xl'}`}>
          {projects.map((proj) => (
            <ProjectCard key={proj.id} project={proj} wide={projects.length === 1} />
          ))}
        </div>

        <div className="mt-14 text-center">
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-xl bg-electric-600 px-6 py-3 text-sm font-semibold text-white shadow-glow hover:bg-electric-500"
          >
            <span>{t('actions.contactMe')}</span>
            <ArrowRight className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
          </Link>
        </div>
      </div>
    </div>
  );
}
