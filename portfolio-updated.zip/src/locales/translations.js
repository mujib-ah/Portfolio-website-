export const translations = {
  en: {
    brandName: 'Mujib Ahmadzai',
    brandTag: 'Intern Front-End Developer',

    nav: {
      home: 'Home',
      about: 'About',
      skills: 'Skills',
      projects: 'Projects',
      experience: 'Experience',
      education: 'Education',
      contact: 'Contact',
      mainLabel: 'Main navigation',
      mobileLabel: 'Mobile navigation',
      menu: 'Menu',
      closeMenu: 'Close menu',
    },

    actions: {
      downloadCV: 'Download CV',
      contactMe: 'Contact Me',
      getInTouch: 'Get In Touch',
      viewProjects: 'View Projects',
      allProjects: 'All Projects',
      liveDemo: 'Live Demo',
      viewCode: 'View Code',
      github: 'GitHub',
      linkedin: 'LinkedIn',
      send: 'Send Message',
      sending: 'Sending...',
      themeLight: 'Switch to light mode',
      themeDark: 'Switch to dark mode',
      langSwitch: 'Switch language to Dari',
      backToHome: 'Back to Home',
      exploreSkills: 'Explore Skills',
      learnMore: 'Learn More About Me',
      copyEmail: 'Copy email',
      emailCopied: 'Copied!',
    },

    loading: {
      title: 'MUJIB AHMADZAI',
      subtitle: 'Intern Front-End Developer',
      skip: 'Skip',
      opening: 'Opening',
    },

    hero: {
      greeting: "Hello, I'm",
      name: 'Mujib Ahmadzai',
      role: 'Intern Front-End Developer',
      intro:
        "I'm Mujib Ahmadzai, an Intern Front-End Developer passionate about turning creative ideas into clean, modern, and interactive web experiences. I enjoy learning new technologies, solving problems, and building websites that combine great design with functionality.",
      badge: 'Open to Internships & Junior Roles',
      photoAlt: 'Mujib Ahmadzai — Intern Front-End Developer',
      photoPlaceholderLabel: 'Initial monogram',
      statProjects: 'Featured Project',
      statSkills: 'Core Technologies',
      statMode: 'Languages',
      visualLabel: 'Profile portrait surrounded by orbiting technology icons and portfolio statistics',
      visualMonogramLabel: 'Decorative MA initials in a circular profile frame, surrounded by orbiting technology icons and portfolio statistics',
      visualTechDescription: 'Orbiting technology icons for React, JavaScript, HTML5, and CSS3',
    },

    home: {
      statsLabel: 'Portfolio statistics',
    },

    about: {
      title: 'About Me',
      subtitle:
        'A glimpse into my background, my journey into front-end development, and the goals that drive me forward every day.',
      introTitle: 'Who I Am',
      introText:
        "I'm Mujib Ahmadzai, an Intern Front-End Developer who believes that great websites live at the intersection of beautiful design and solid code. I approach every project with curiosity, attention to detail, and a commitment to writing clean, maintainable code.",
      journeyTitle: 'My Journey in Front-End Development',
      journeyText:
        'My path started with the fundamentals — understanding how the web works through HTML and CSS — and quickly grew into a deep curiosity about making things interactive with modern JavaScript and React. Through consistent practice, building real projects, and exploring modern tooling, I have developed a practical, hands-on foundation in front-end development that I keep sharpening every day.',
      passionTitle: 'My Passion for Web Development',
      passionText:
        'What excites me most about front-end engineering is the instant feedback loop between writing code and seeing something useful come alive in the browser. I care about responsive layouts that look intentional on every device, thoughtful micro-interactions, accessibility, and the craft of translating ideas into polished user interfaces.',
      learningTitle: 'My Learning Interests',
      learningItems: [
        'Advanced React patterns, state management, and modern component architecture',
        'TypeScript for safer and more scalable applications',
        'Next.js and full-stack JavaScript foundations',
        'Web performance optimization and accessibility best practices',
        'Modern CSS techniques, animations, and design systems',
      ],
      goalsTitle: 'My Professional Goals',
      goalsText:
        'My short-term goal is to join a forward-thinking team as an intern or junior front-end developer where I can contribute to real-world products, learn from experienced engineers, and grow quickly. In the long term, I aim to become a versatile front-end engineer known for delivering premium user experiences and technically rigorous web applications.',
      placeholderTitle: 'More to Come',
      placeholderText:
        'Additional personal background, certifications, and milestones will be added here as my journey continues.',
      coreValuesTitle: 'What I Value Most',
      coreValues: [
        { title: 'Clean Code', desc: 'Readable, organized, and maintainable — code is written for humans first.' },
        { title: 'User Experience', desc: 'Interfaces should feel effortless, fast, and delightful to interact with.' },
        { title: 'Continuous Growth', desc: 'Every day is an opportunity to learn a new tool, pattern, or perspective.' },
      ],
    },

    skills: {
      title: 'Skills & Technologies',
      subtitle:
        'These are my confirmed technologies — the tools and foundations I use every day to build modern web interfaces.',
      coreTitle: 'Confirmed Core Skills',
      notesTitle: 'Skill Philosophy',
      notesText:
        'I list only the technologies I actually work with. Rather than invented ratings or skill percentages, each skill represents hands-on familiarity and daily practice.',
      practiceLabel: 'Hands-on practice',
      categoryWeb: 'Web Fundamentals',
      categoryFramework: 'Frameworks & Libraries',
      categoryTools: 'Tools & Workflow',
      categoryDesign: 'Styling & Design',
    },

    projects: {
      title: 'My Projects',
      subtitle:
        'A curated collection of web projects I have built. More projects will be added as my portfolio grows.',
      featuredBadge: 'Featured',
      categoryLabel: 'Category',
      techLabel: 'Technologies',
      filterAll: 'All',
      liveUnavailable: 'Live demo link will be added soon',
      codeUnavailable: 'Repository will be linked soon',
      previewTitle: 'Project preview',
      previewHint: 'Open the live demo to explore this project',
    },

    experience: {
      title: 'Experience',
      subtitle:
        'My professional journey, freelance activities, and career goals as an aspiring Front-End Developer.',
      jobTitle: 'Job Title',
      employmentType: 'Employment Type',
      workType: 'Work Type',
      duration: 'Duration',
      responsibilities: 'Responsibilities',
      technologies: 'Technologies',
      status: 'Status',
      focusAreas: 'Focus Areas',
    },

    education: {
      title: 'Education',
      subtitle:
        'An overview of my university studies, professional training, and high school education.',
      categoryUniversity: 'University Education',
      categoryTraining: 'Professional Training',
      categoryHighSchool: 'High School Education',
      degreeLabel: 'Degree',
      certificateLabel: 'Certificate',
      qualificationLabel: 'Qualification',
      fieldOfStudy: 'Field of Study',
      duration: 'Duration',
      grade: 'Grade',
      activities: 'Activities and Involvement',
      description: 'Description',
      inProgress: 'In Progress',
    },

    contact: {
      title: 'Contact Me',
      subtitle:
        'Have an internship opportunity, a freelance project, or just want to say hello? I would love to hear from you.',
      infoTitle: 'Get in Touch',
      infoText:
        'Feel free to reach out through the form below or directly via email and social channels. I usually respond within 24–48 hours.',
      emailLabel: 'Email',
      linkedinLabel: 'LinkedIn',
      githubLabel: 'GitHub',
      locationLabel: 'Location',
      formTitle: 'Send a Message',
      nameLabel: 'Full Name',
      namePlaceholder: 'Your full name',
      emailFieldLabel: 'Email Address',
      emailPlaceholder: 'you@example.com',
      subjectLabel: 'Subject',
      subjectPlaceholder: 'What would you like to discuss?',
      messageLabel: 'Message',
      messagePlaceholder: 'Write your message here...',
      sendButton: 'Send Message',
      validationErrors: {
        nameRequired: 'Please enter your name.',
        emailRequired: 'Please enter your email address.',
        emailInvalid: 'Please enter a valid email address.',
        subjectRequired: 'Please enter a subject.',
        messageRequired: 'Please enter a message.',
        messageTooShort: 'Message must be at least 10 characters.',
      },
      statusSuccess:
        'Thank you! Your message has been received. I will get back to you as soon as possible.',
      statusError:
        'Something went wrong while sending your message. Please try again or email me directly.',
      statusUnconfiguredTitle: 'Direct messaging is being configured',
      statusUnconfigured:
        'The contact form endpoint is not yet configured for this portfolio. Your message details have been preserved below — please copy them or click to open your email client.',
      responseTimeLabel: 'Response Time',
      responseTimeText: 'I usually reply within 24–48 hours on business days.',
      copyMessageDetails: 'Copy message details',
      openEmailClient: 'Open email client',
      requiredHint: 'All fields are required.',
    },

    footer: {
      tagline: 'Turning creative ideas into clean, modern, and interactive web experiences.',
      navTitle: 'Navigation',
      connectTitle: 'Connect',
      rights: 'All rights reserved.',
      builtWith: 'Built with React, Vite & Tailwind CSS',
    },

    notFound: {
      title: 'Page Not Found',
      text: 'The page you are looking for does not exist or has been moved.',
      home: 'Return to Home',
    },

    common: {
      tag: 'Portfolio',
      skipToContent: 'Skip to main content',
      backToTop: 'Back to top',
    },
  },

  da: {
    brandName: 'مجیب احمدزی',
    brandTag: 'انترن فرانت‌اند دولوپر',

    nav: {
      home: 'خانه',
      about: 'درباره من',
      skills: 'مهارت‌ها',
      projects: 'پروژه‌ها',
      experience: 'تجربه کاری',
      education: 'تحصیلات',
      contact: 'تماس با من',
      mainLabel: 'پیمایش اصلی',
      mobileLabel: 'منوی موبایل',
      menu: 'منو',
      closeMenu: 'بستن منو',
    },

    actions: {
      downloadCV: 'دانلود سی‌وی',
      contactMe: 'تماس با من',
      getInTouch: 'در ارتباط باشید',
      viewProjects: 'مشاهده پروژه‌ها',
      allProjects: 'همه پروژه‌ها',
      liveDemo: 'دموی زنده',
      viewCode: 'مشاهده کد',
      github: 'گیت‌هاب',
      linkedin: 'لینکدین',
      send: 'ارسال پیام',
      sending: 'در حال ارسال...',
      themeLight: 'تغییر به حالت روشن',
      themeDark: 'تغییر به حالت تاریک',
      langSwitch: 'Switch language to English',
      backToHome: 'بازگشت به خانه',
      exploreSkills: 'بررسی مهارت‌ها',
      learnMore: 'بیشتر درباره من بدانید',
      copyEmail: 'کاپی ایمیل',
      emailCopied: 'کاپی شد!',
    },

    loading: {
      title: 'مجیب احمدزی',
      subtitle: 'انترن فرانت‌اند دولوپر',
      skip: 'رد کردن',
      opening: 'در حال باز کردن',
    },

    hero: {
      greeting: 'سلام، من هستم',
      name: 'مجیب احمدزی',
      role: 'انترن فرانت‌اند دولوپر',
      intro:
        'من مجیب احمدزی هستم، یک انترن فرانت‌اند دولوپر که به تبدیل ایده‌های خلاقانه به تجربه‌های وب تمیز، مدرن و تعاملی علاقه‌مند است. از یادگیری تکنالوژی‌های نو، حل مسائل و ساخت وب‌سایت‌هایی که دیزاین عالی را با کارایی همراه می‌کنند، لذت می‌برم.',
      badge: 'آماده برای کارآموزی و فرصت‌های جونیور',
      photoAlt: 'مجیب احمدزی — انترن فرانت‌اند دولوپر',
      photoPlaceholderLabel: 'نشان حروف اختصاری',
      statProjects: 'پروژه ویژه',
      statSkills: 'تکنالوژی‌های اصلی',
      statMode: 'زبان‌ها',
      visualLabel: 'تصویر پروفایل در میان آیکون‌های تکنالوژی و آمار پورتفولیو',
      visualMonogramLabel: 'حروف اختصاری MA در قاب دایره‌ای با آیکون‌های شناور تکنالوژی و آمار پورتفولیو',
      visualTechDescription: 'آیکون‌های شناور React، JavaScript، HTML5 و CSS3',
    },

    home: {
      statsLabel: 'آمار پورتفولیو',
    },

    about: {
      title: 'درباره من',
      subtitle:
        'نگاهی به پیشینه من، مسیرم در توسعه فرانت‌اند و اهدافی که هر روز به پیش می‌روم.',
      introTitle: 'من کی هستم',
      introText:
        'من مجیب احمدزی هستم، یک انترن فرانت‌اند دولوپر که باور دارد وب‌سایت‌های عالی در نقطه تلاقی دیزاین زیبا و کدنویسی دقیق شکل می‌گیرند. هر پروژه‌ای را با کنجکاوی، دقت به جزئیات و تعهد به نوشتن کد تمیز و قابل حفظ پیش می‌برم.',
      journeyTitle: 'مسیر من در توسعه فرانت‌اند',
      journeyText:
        'مسیر من با مبانی شروع شد — فهمیدن نحوه کار وب از طریق HTML و CSS — و سپس به کنجکاوی عمیق‌تر در مورد ساخت بخش‌های تعاملی با جاوااسکریپت مدرن و React گسترش یافت. با تمرین پیوسته، ساخت پروژه‌های واقعی و کاوش در ابزارهای مدرن، پایه‌ای عملی و کاربردی در فرانت‌اند ایجاد کرده‌ام که هر روز آن را تقویت می‌کنم.',
      passionTitle: 'علاقه من به توسعه وب',
      passionText:
        'آنچه مرا بیشتر از همه در مهندسی فرانت‌اند هیجان‌زده می‌کند، نتیجه فوری نوشتن کد و دیدن یک تجربه مفید در براوزر است. به چیدمان‌های ریسپانسیو که در هر دستگاه عالی به نظر می‌رسند، تعاملات دقیق و ظریف، دسترسی‌پذیری و هنر تبدیل ایده‌ها به رابط‌های کاربری جذاب اهمیت می‌دهم.',
      learningTitle: 'علاقه‌مندی‌های یادگیری من',
      learningItems: [
        'الگوهای پیشرفته React، مدیریت وضعیت و معماری مؤلفه‌های مدرن',
        'تایپ‌اسکریپت برای برنامه‌های ایمن‌تر و قابل توسعه‌تر',
        'Next.js و پایه‌های تمام‌استک جاوااسکریپت',
        'بهینه‌سازی سرعت وب و بهترین شیوه‌های دسترسی‌پذیری',
        'تکنیک‌های مدرن CSS، انیمیشن‌ها و سیستم‌های دیزاین',
      ],
      goalsTitle: 'اهداف مسلکی من',
      goalsText:
        'هدف کوتاه‌مدت من پیوستن به یک تیم پیشرو به عنوان انترن یا فرانت‌اند دولوپر جونیور است، جایی که بتوانم در ساخت محصولات واقعی سهم بگیرم، از انجینیران باتجربه بیاموزم و به سرعت رشد کنم. در درازمدت، هدفم تبدیل شدن به یک فرانت‌اند انجینیر ورزیده با قابلیت ساخت تجربه‌های کاربری ممتاز و برنامه‌های وب فنی و دقیق است.',
      placeholderTitle: 'بیشتر در آینده',
      placeholderText:
        'جزئیات شخصی دیگر، تصدیق‌نامه‌ها و دستاوردهای جدید با پیشرفت مسیرم در اینجا افزوده خواهند شد.',
      coreValuesTitle: 'ارزش‌های مهم برای من',
      coreValues: [
        { title: 'کد تمیز', desc: 'خوانا، منظم و قابل نگهداری — کد اول برای انسان‌ها نوشته می‌شود.' },
        { title: 'تجربه کاربری', desc: 'رابط‌ها باید آسان، سریع و برای تعامل لذت‌بخش باشند.' },
        { title: 'رشد مداوم', desc: 'هر روز فرصتی برای یادگیری یک ابزار، الگو یا دیدگاه جدید است.' },
      ],
    },

    skills: {
      title: 'مهارت‌ها و تکنالوژی‌ها',
      subtitle:
        'این‌ها تکنالوژی‌های تأییدشده من هستند — ابزارها و مبانی که هر روز برای ساخت رابط‌های وب مدرن استفاده می‌کنم.',
      coreTitle: 'مهارت‌های اصلی تأییدشده',
      notesTitle: 'دیدگاه من به مهارت‌ها',
      notesText:
        'تنها تکنالوژی‌هایی را ذکر می‌کنم که واقعاً با آن‌ها کار می‌کنم. به جای نمرات یا فیصدی‌های ساختگی، هر مهارت بیانگر آشنایی عملی و تمرین روزمره است.',
      practiceLabel: 'تمرین عملی',
      categoryWeb: 'مبانی وب',
      categoryFramework: 'فریم‌ورک‌ها و کتابخانه‌ها',
      categoryTools: 'ابزارها و روند کار',
      categoryDesign: 'استایل‌دهی و دیزاین',
    },

    projects: {
      title: 'پروژه‌های من',
      subtitle:
        'مجموعه‌ای از پروژه‌های وب که ساخته‌ام. با گسترش نمونه‌کارهایم پروژه‌های بیشتری اضافه خواهند شد.',
      featuredBadge: 'ویژه',
      categoryLabel: 'دسته‌بندی',
      techLabel: 'تکنالوژی‌ها',
      filterAll: 'همه',
      liveUnavailable: 'لینک دموی زنده به زودی افزوده می‌شود',
      codeUnavailable: 'لینک مخزن کد به زودی پیوست می‌شود',
      previewTitle: 'نمای پروژه',
      previewHint: 'برای دیدن پروژه، دموی زنده را باز کنید',
    },

    experience: {
      title: 'تجربه کاری',
      subtitle:
        'مسیر مسلکی، فعالیت‌های فریلنس و اهداف شغلی من به عنوان یک توسعه‌دهنده مشتاق فرانت‌اند.',
      jobTitle: 'عنوان وظیفه',
      employmentType: 'نوع استخدام',
      workType: 'نوع کار',
      duration: 'مدت',
      responsibilities: 'مسئولیت‌ها',
      technologies: 'تکنالوژی‌ها',
      status: 'وضعیت',
      focusAreas: 'حوزه‌های تمرکز',
    },

    education: {
      title: 'تحصیلات',
      subtitle:
        'مروری بر تحصیلات پوهنتونی، آموزش مسلکی و دوره مکتب من.',
      categoryUniversity: 'تحصیلات پوهنتونی',
      categoryTraining: 'آموزش مسلکی',
      categoryHighSchool: 'تحصیلات لیسه',
      degreeLabel: 'درجه تحصیلی',
      certificateLabel: 'گواهی‌نامه',
      qualificationLabel: 'مدرک تحصیلی',
      fieldOfStudy: 'رشته تحصیلی',
      duration: 'مدت',
      grade: 'نمره',
      activities: 'فعالیت‌ها و مشارکت',
      description: 'توضیحات',
      inProgress: 'در حال تکمیل',
    },

    contact: {
      title: 'تماس با من',
      subtitle:
        'فرصت کارآموزی، پروژه آزاد یا فقط قصد سلام دادن دارید؟ خوشحال می‌شوم از شما بشنوم.',
      infoTitle: 'در ارتباط باشید',
      infoText:
        'می‌توانید از طریق فورم پایین یا مستقیماً از طریق ایمیل و شبکه‌های اجتماعی پیام بفرستید. معمولاً ظرف ۲۴ تا ۴۸ ساعت پاسخ می‌دهم.',
      emailLabel: 'ایمیل',
      linkedinLabel: 'لینکدین',
      githubLabel: 'گیت‌هاب',
      locationLabel: 'موقعیت',
      formTitle: 'ارسال پیام',
      nameLabel: 'نام مکمل',
      namePlaceholder: 'نام مکمل شما',
      emailFieldLabel: 'آدرس ایمیل',
      emailPlaceholder: 'you@example.com',
      subjectLabel: 'موضوع',
      subjectPlaceholder: 'در چه موردی می‌خواهید گفتگو کنید؟',
      messageLabel: 'پیام',
      messagePlaceholder: 'پیام خود را در اینجا بنویسید...',
      sendButton: 'ارسال پیام',
      validationErrors: {
        nameRequired: 'لطفاً نام خود را وارد کنید.',
        emailRequired: 'لطفاً آدرس ایمیل خود را وارد کنید.',
        emailInvalid: 'لطفاً یک آدرس ایمیل معتبر وارد کنید.',
        subjectRequired: 'لطفاً موضوع را وارد کنید.',
        messageRequired: 'لطفاً پیام خود را وارد کنید.',
        messageTooShort: 'پیام باید حداقل ۱۰ حرف داشته باشد.',
      },
      statusSuccess:
        'تشکر! پیام شما دریافت شد. در اولین فرصت با شما تماس خواهم گرفت.',
      statusError:
        'مشکلی در ارسال پیام رخ داد. لطفاً دوباره تلاش کنید یا مستقیماً ایمیل بفرستید.',
      statusUnconfiguredTitle: 'سیستم پیام‌رسانی در حال تنظیم است',
      statusUnconfigured:
        'آدرس ارسال فورم هنوز تنظیم نشده است. جزئیات پیام شما در پایین محفوظ است — می‌توانید آن‌ها را کاپی کنید یا با کلیک برنامه ایمیل خود را باز نمایید.',
      responseTimeLabel: 'زمان پاسخ‌دهی',
      responseTimeText: 'معمولاً ظرف ۲۴ تا ۴۸ ساعت در روزهای کاری پاسخ می‌دهم.',
      copyMessageDetails: 'کاپی جزئیات پیام',
      openEmailClient: 'باز کردن ایمیل',
      requiredHint: 'پر کردن تمام خانه‌ها الزامی است.',
    },

    footer: {
      tagline: 'تبدیل ایده‌های خلاقانه به تجربه‌های وب تمیز، مدرن و تعاملی.',
      navTitle: 'صفحات',
      connectTitle: 'ارتباط',
      rights: 'تمام حقوق محفوظ است.',
      builtWith: 'ساخته شده با React، Vite و Tailwind CSS',
    },

    notFound: {
      title: 'صفحه پیدا نشد',
      text: 'صفحه‌ای که جستجو می‌کنید وجود ندارد یا منتقل شده است.',
      home: 'بازگشت به خانه',
    },

    common: {
      tag: 'پورتفولیو',
      skipToContent: 'رفتن به محتوای اصلی',
      backToTop: 'برگشت به بالا',
    },
  },
};

export default translations;
