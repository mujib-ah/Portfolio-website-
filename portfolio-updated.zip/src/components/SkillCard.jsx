import { motion, useReducedMotion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.48, ease: [0.22, 1, 0.36, 1] } },
};

export default function SkillCard({ skill }) {
  const { language, t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const desc = skill.description?.[language] || skill.description?.en;

  return (
    <motion.article
      variants={itemVariants}
      whileHover={reduceMotion ? undefined : { y: -6, scale: 1.012 }}
      whileTap={reduceMotion ? undefined : { scale: 0.992 }}
      transition={{ type: 'spring', stiffness: 320, damping: 26 }}
      className="spotlight group relative flex h-full flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/90 bg-white/90 p-5 shadow-sm backdrop-blur transition-[border-color,box-shadow,background-color] duration-300 hover:border-electric-300 hover:shadow-[0_22px_45px_-30px_rgba(14,127,231,0.65)] dark:border-slate-800 dark:bg-slate-900/90 dark:hover:border-electric-800"
    >
      <div aria-hidden="true" className="pointer-events-none absolute -end-12 -top-12 h-32 w-32 rounded-full bg-electric-500/0 blur-2xl transition-colors duration-500 group-hover:bg-electric-500/10" />
      <div className="relative">
        <div className="flex items-center justify-between">
          <motion.div whileHover={reduceMotion ? undefined : { rotate: -5, scale: 1.08 }} transition={{ type: 'spring', stiffness: 350, damping: 18 }} className="flex h-12 w-12 items-center justify-center rounded-xl" style={{ backgroundColor: `${skill.color}15`, color: skill.color }}>
            <i className={`${skill.faIcon} text-2xl`} aria-hidden="true" />
          </motion.div>
        </div>
        <h3 className="mt-4 text-base font-bold text-slate-900 transition-colors dark:text-white group-hover:text-electric-600 dark:group-hover:text-electric-400">{skill.name}</h3>
        <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-400">{desc}</p>
      </div>
      <div className="relative mt-4 flex items-center justify-between border-t border-slate-100 pt-3 text-[11px] text-slate-400 dark:border-slate-800 dark:text-slate-500">
        <span>{t('skills.practiceLabel')}</span><span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: skill.color }} />
      </div>
    </motion.article>
  );
}
