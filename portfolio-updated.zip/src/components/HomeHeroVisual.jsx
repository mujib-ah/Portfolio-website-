import { useEffect, useRef, useState } from 'react';
import { motion, useMotionValue, useReducedMotion, useSpring, useTransform } from 'framer-motion';
import { Code2, Languages, Sparkles } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import siteConfig from '../config/site';
import skills from '../data/skills';

const technologies = [
  { id: 'react', label: 'React', icon: 'fa-brands fa-react', position: 'start-[12%] top-[18%] sm:top-[15%]', color: 'text-sky-500' },
  { id: 'javascript', label: 'JavaScript', icon: 'fa-brands fa-js', position: 'end-[12%] top-[31%] sm:top-[29%]', color: 'text-amber-500' },
  { id: 'html', label: 'HTML5', icon: 'fa-brands fa-html5', position: 'end-[12%] bottom-[24%]', color: 'text-orange-500' },
  { id: 'css', label: 'CSS3', icon: 'fa-brands fa-css3-alt', position: 'start-[12%] bottom-[24%]', color: 'text-blue-500' },
];

const floatTransition = (duration, delay = 0) => ({
  duration,
  delay,
  repeat: Infinity,
  repeatType: 'mirror',
  ease: 'easeInOut',
});

export default function HomeHeroVisual() {
  const { t, language } = useLanguage();
  const reduceMotion = useReducedMotion();
  const name = language === 'da' ? siteConfig.nameDari : siteConfig.name;
  const role = language === 'da' ? siteConfig.roleDari : siteConfig.role;
  const avatarRef = useRef(null);
  const [avatarLoaded, setAvatarLoaded] = useState(false);

  const pointerX = useMotionValue(0);
  const pointerY = useMotionValue(0);
  const spring = { stiffness: 140, damping: 18, mass: 0.6 };
  const tiltY = useSpring(useTransform(pointerX, [-0.5, 0.5], [-9, 9]), spring);
  const tiltX = useSpring(useTransform(pointerY, [-0.5, 0.5], [9, -9]), spring);
  const badgeX = useSpring(useTransform(pointerX, [-0.5, 0.5], [10, -10]), spring);
  const badgeY = useSpring(useTransform(pointerY, [-0.5, 0.5], [8, -8]), spring);

  const handlePointerMove = (e) => {
    if (reduceMotion || e.pointerType !== 'mouse') return;
    const rect = e.currentTarget.getBoundingClientRect();
    pointerX.set((e.clientX - rect.left) / rect.width - 0.5);
    pointerY.set((e.clientY - rect.top) / rect.height - 0.5);
  };
  const resetPointer = () => {
    pointerX.set(0);
    pointerY.set(0);
  };

  useEffect(() => {
    if (avatarRef.current?.complete) setAvatarLoaded(true);
  }, []);

  return (
    <div onPointerMove={handlePointerMove} onPointerLeave={resetPointer} className="relative mx-auto h-[350px] w-full max-w-[450px] select-none sm:h-[420px] lg:h-[470px]" role="img" aria-label={siteConfig.avatar ? t('hero.visualLabel') : t('hero.visualMonogramLabel')}>
      <div aria-hidden="true" className="pointer-events-none absolute inset-[8%] rounded-full bg-electric-400/10 blur-3xl dark:bg-electric-500/10" />

      <motion.svg
        aria-hidden="true"
        viewBox="0 0 440 440"
        className="pointer-events-none absolute inset-0 h-full w-full text-electric-400/35 dark:text-electric-300/20"
        animate={reduceMotion ? undefined : { rotate: 360 }}
        transition={{ duration: 72, repeat: Infinity, ease: 'linear' }}
      >
        <ellipse cx="220" cy="220" rx="184" ry="126" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="2 9" transform="rotate(-22 220 220)" />
        <ellipse cx="220" cy="220" rx="156" ry="186" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="1 11" transform="rotate(28 220 220)" />
      </motion.svg>

      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <motion.div
          className="h-[258px] w-[258px] rounded-full border border-electric-400/25 sm:h-[324px] sm:w-[324px]"
          animate={reduceMotion ? undefined : { scale: [1, 1.025, 1], opacity: [0.55, 0.9, 0.55] }}
          transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
        />
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-1/2 h-[230px] w-[230px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-electric-400/20 sm:h-[292px] sm:w-[292px]" />

      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <motion.div
          className="relative h-[204px] w-[204px] rounded-full sm:h-[258px] sm:w-[258px]"
          style={reduceMotion ? undefined : { rotateX: tiltX, rotateY: tiltY, transformPerspective: 900 }}
          initial={reduceMotion ? false : { opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: reduceMotion ? 0 : 0.7, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
        >
          <motion.div
            aria-hidden="true"
            className="absolute -inset-2 rounded-full bg-gradient-to-br from-electric-400/65 via-sky-300/25 to-indigo-400/45 blur-xl"
            animate={reduceMotion ? undefined : { opacity: [0.35, 0.65, 0.35], scale: [0.98, 1.04, 0.98] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          />
          <div className="absolute inset-0 overflow-hidden rounded-full border-[7px] border-white bg-gradient-to-br from-white via-electric-50 to-sky-100 shadow-[0_30px_90px_-28px_rgba(14,127,231,0.58)] ring-1 ring-electric-500/15 dark:border-slate-800 dark:from-slate-900 dark:via-slate-900 dark:to-electric-950">
            {siteConfig.avatar ? (
              <img
                ref={avatarRef}
                src={siteConfig.avatar}
                srcSet={siteConfig.avatarSrcSet}
                sizes="(min-width: 640px) 420px, 350px"
                width={siteConfig.avatarSize?.width}
                height={siteConfig.avatarSize?.height}
                alt={t('hero.photoAlt')}
                className={`h-full w-full rounded-full object-cover transition-opacity duration-500 ${avatarLoaded ? 'opacity-100' : 'opacity-0'}`}
                style={{ objectPosition: siteConfig.avatarPosition || 'center' }}
                loading="lazy"
                decoding="async"
                onLoad={() => setAvatarLoaded(true)}
              />
            ) : (
              <div className="relative flex h-full w-full flex-col items-center justify-center overflow-hidden text-center">
                <div aria-hidden="true" className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,rgba(14,127,231,0.16),transparent_58%)] dark:bg-[radial-gradient(circle_at_50%_35%,rgba(14,127,231,0.22),transparent_58%)]" />
                <motion.div
                  className="relative flex h-[88px] w-[88px] items-center justify-center rounded-[28px] border border-white/75 bg-gradient-to-br from-electric-500 to-blue-700 text-3xl font-black tracking-[-0.08em] text-white shadow-[0_18px_44px_-12px_rgba(14,127,231,0.72)] sm:h-[104px] sm:w-[104px] sm:rounded-[34px] sm:text-4xl"
                  whileHover={reduceMotion ? undefined : { rotate: -4, scale: 1.035 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                >
                  MA
                </motion.div>
                <p className="relative mt-4 max-w-[80%] text-sm font-bold tracking-tight text-slate-800 dark:text-slate-100">{name}</p>
                <p className="relative mt-1 text-[11px] font-medium text-electric-700 dark:text-electric-300">{role}</p>
                <span className="relative mt-3 inline-flex items-center gap-1.5 rounded-full border border-white/80 bg-white/75 px-3 py-1 text-[10px] font-semibold text-slate-500 shadow-sm backdrop-blur dark:border-slate-700 dark:bg-slate-800/75 dark:text-slate-300">
                  <Sparkles className="h-3 w-3 text-electric-500" aria-hidden="true" />
                  {t('hero.photoPlaceholderLabel')}
                </span>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      <motion.div aria-hidden="true" className="pointer-events-none absolute inset-0" style={reduceMotion ? undefined : { x: badgeX, y: badgeY }}>
        {technologies.map((technology, index) => (
          <motion.div
            key={technology.id}
            className={`absolute z-10 ${technology.position} flex h-9 w-9 items-center justify-center rounded-xl border border-white/90 bg-white/95 text-base shadow-[0_10px_28px_-12px_rgba(15,23,42,0.3)] backdrop-blur transition-colors dark:border-slate-700 dark:bg-slate-900/95 sm:h-11 sm:w-11 sm:rounded-2xl sm:text-lg ${technology.color}`}
            animate={reduceMotion ? undefined : { y: [0, index % 2 === 0 ? -5 : 5, 0] }}
            transition={floatTransition(4.6 + index * 0.28, index * 0.17)}
            whileHover={reduceMotion ? undefined : { scale: 1.12, rotate: index % 2 === 0 ? 5 : -5 }}
            title={technology.label}
          >
            <i className={technology.icon} aria-hidden="true" />
          </motion.div>
        ))}
      </motion.div>

      <motion.div
        className="pointer-events-none absolute end-[2%] top-[4%] z-20 flex items-center gap-2.5 rounded-2xl border border-white/90 bg-white/90 px-3 py-2.5 shadow-[0_16px_38px_-20px_rgba(15,23,42,0.3)] backdrop-blur dark:border-slate-700 dark:bg-slate-900/90 sm:end-[3%] sm:px-4 sm:py-3"
        animate={reduceMotion ? undefined : { y: [0, -5, 0] }}
        transition={floatTransition(5.8, 0.2)}
      >
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-electric-50 text-electric-600 dark:bg-electric-950/70 dark:text-electric-300"><Code2 className="h-4 w-4" aria-hidden="true" /></span>
        <span className="whitespace-nowrap text-start">
          <span className="block text-sm font-extrabold leading-none text-slate-900 dark:text-white">{skills.length}</span>
          <span className="mt-1 block text-[9px] font-semibold text-slate-500 dark:text-slate-400">{t('hero.statSkills')}</span>
        </span>
      </motion.div>

      <motion.div
        className="pointer-events-none absolute start-0 bottom-[3%] z-20 flex max-w-full items-center gap-2.5 rounded-2xl border border-white/90 bg-white/90 px-3 py-2.5 shadow-[0_16px_38px_-20px_rgba(15,23,42,0.3)] backdrop-blur dark:border-slate-700 dark:bg-slate-900/90 sm:px-4 sm:py-3"
        animate={reduceMotion ? undefined : { y: [0, 5, 0] }}
        transition={floatTransition(6.4, 0.4)}
      >
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-sky-50 text-sky-600 dark:bg-sky-950/60 dark:text-sky-300"><Languages className="h-4 w-4" aria-hidden="true" /></span>
        <span className="whitespace-nowrap text-start">
          <span className="block text-sm font-extrabold leading-none text-slate-900 dark:text-white">2</span>
          <span className="mt-1 block text-[9px] font-semibold text-slate-500 dark:text-slate-400">{t('hero.statMode')}</span>
        </span>
      </motion.div>
    </div>
  );
}
