import { useLanguage } from '../context/LanguageContext';
import { motion, useReducedMotion } from 'framer-motion';

export default function SectionHeader({
  eyebrow,
  title,
  subtitle,
  center = true,
  className = '',
  hLevel = 2,
}) {
  const { isRTL } = useLanguage();
  const reduceMotion = useReducedMotion();

  return (
    <motion.div initial={reduceMotion ? false : { opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.2 }} transition={{ duration: reduceMotion ? 0.12 : 0.52, ease: [0.22, 1, 0.36, 1] }} className={`${center ? 'text-center' : ''} ${className}`}>
      {eyebrow && (
        <p className="mb-3 inline-flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-electric-600 dark:text-electric-400">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-electric-500 shadow-glow" />
          {eyebrow}
        </p>
      )}
      {hLevel === 1 ? (
        <h1 className="text-3xl font-extrabold tracking-[-0.035em] text-slate-950 sm:text-4xl lg:text-5xl dark:text-white">
          {title}
        </h1>
      ) : (
        <h2 className="text-2xl font-extrabold tracking-[-0.03em] text-slate-950 sm:text-3xl dark:text-white">
          {title}
        </h2>
      )}
      <motion.span
        aria-hidden="true"
        initial={reduceMotion ? false : { scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true, amount: 0.8 }}
        transition={{ duration: 0.7, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
        style={{ originX: center ? 0.5 : isRTL ? 1 : 0 }}
        className={`mt-3 block h-1 w-14 rounded-full bg-gradient-to-r from-electric-500 to-sky-400 ${center ? 'mx-auto' : ''}`}
      />
      {subtitle && (
        <p
          className={`mt-4 max-w-2xl text-sm leading-7 text-slate-600 sm:text-base dark:text-slate-400 ${
            center ? 'mx-auto' : ''
          }`}
        >
          {subtitle}
        </p>
      )}
    </motion.div>
  );
}
