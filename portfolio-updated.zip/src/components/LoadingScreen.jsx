import { useEffect, useRef, useState } from 'react';
import { useReducedMotion } from 'framer-motion';
import siteConfig from '../config/site';
import { useLanguage } from '../context/LanguageContext';

export default function LoadingScreen({ onFinish }) {
  const { t, language } = useLanguage();
  const reduceMotion = useReducedMotion();
  const [visible, setVisible] = useState(0);
  const [fading, setFading] = useState(false);
  const finishRef = useRef(onFinish);
  const finishedRef = useRef(false);
  const isDari = language === 'da';
  const name = isDari ? siteConfig.nameDari : siteConfig.loadingScreen.displayName;
  const units = isDari ? name.split(' ') : name.split('');
  const total = units.length;

  useEffect(() => {
    finishRef.current = onFinish;
  }, [onFinish]);

  const finish = (delay) => {
    setFading(true);
    return setTimeout(() => {
      if (finishedRef.current) return;
      finishedRef.current = true;
      finishRef.current?.();
    }, delay);
  };

  useEffect(() => {
    const timers = [];
    let interval;
    if (reduceMotion) {
      setVisible(total);
    } else {
      setVisible(0);
      const stepMs = Math.max(40, Math.floor(750 / total));
      interval = setInterval(() => {
        setVisible((n) => {
          if (n >= total) {
            clearInterval(interval);
            return n;
          }
          return n + 1;
        });
      }, stepMs);
    }
    timers.push(setTimeout(() => timers.push(finish(reduceMotion ? 0 : 300)), siteConfig.loadingScreen.autoCloseMs));
    return () => {
      clearInterval(interval);
      timers.forEach(clearTimeout);
    };
  }, [total, reduceMotion]);

  const handleSkip = () => {
    finish(250);
  };

  return (
    <div
      role="status"
      aria-label={t('loading.title')}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white transition-opacity duration-300 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <div
        aria-hidden="true"
        className={`pointer-events-none absolute h-96 w-96 rounded-full bg-electric-500/20 blur-3xl ${reduceMotion ? '' : 'animate-pulse-slow'}`}
      />

      <div className="relative text-center px-4 select-none">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-electric-600 text-sm font-extrabold tracking-widest text-white shadow-glow">
          MA
        </div>

        <h1
          className={`text-2xl sm:text-4xl md:text-5xl font-extrabold text-white ${isDari ? 'tracking-normal' : 'tracking-[0.25em]'}`}
          style={{ textShadow: '0 0 30px rgba(0, 168, 255, 0.45)' }}
        >
          {units.map((unit, i) => (
            <span
              key={i}
              className={`inline-block transition-all duration-300 ${
                reduceMotion || i < visible
                  ? 'opacity-100 translate-y-0 text-electric-400 drop-shadow-[0_0_12px_rgba(14,127,231,0.7)]'
                  : 'opacity-0 translate-y-3'
              } ${isDari ? 'mx-1.5 sm:mx-2.5' : unit === ' ' ? 'w-3 sm:w-5' : ''}`}
            >
              {unit}
            </span>
          ))}
        </h1>

        <p className="mt-4 text-xs sm:text-sm tracking-widest uppercase text-slate-400 font-medium">
          {t('loading.subtitle')}
        </p>

        <div className="mx-auto mt-6 h-0.5 w-40 overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full bg-electric-500 shadow-glow transition-all duration-300"
            style={{ width: `${((reduceMotion ? total : visible) / total) * 100}%` }}
          />
        </div>
      </div>

      <button
        type="button"
        onClick={handleSkip}
        className="absolute bottom-6 end-6 text-[11px] text-slate-500 transition-colors hover:text-slate-300"
      >
        {t('loading.skip')} {language === 'da' ? '←' : '→'}
      </button>
    </div>
  );
}
