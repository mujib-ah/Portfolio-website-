import { useEffect, useState } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import ThemeToggle from './ThemeToggle';
import LanguageSwitcher from './LanguageSwitcher';
import DownloadCVButton from './DownloadCVButton';
import siteConfig from '../config/site';

const navItems = [
  { path: '/', key: 'nav.home' },
  { path: '/about', key: 'nav.about' },
  { path: '/skills', key: 'nav.skills' },
  { path: '/projects', key: 'nav.projects' },
  { path: '/experience', key: 'nav.experience' },
  { path: '/education', key: 'nav.education' },
  { path: '/contact', key: 'nav.contact' },
];

export default function Navbar() {
  const { t, language } = useLanguage();
  const [mobileOpen, setMobileOpen] = useState(false);
  const reduceMotion = useReducedMotion();
  const { pathname } = useLocation();
  const desktopNavBreakpoint = 'min-[950px]:flex';
  const mobileNavBreakpoint = 'min-[950px]:hidden';

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!mobileOpen) return undefined;
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setMobileOpen(false);
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [mobileOpen]);

  const name = language === 'da' ? siteConfig.nameDari : siteConfig.name;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/70 bg-white/85 shadow-[0_8px_30px_-24px_rgba(15,23,42,0.45)] backdrop-blur-xl transition-colors duration-300 dark:border-slate-800/70 dark:bg-slate-950/95">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link
          to="/"
          aria-label={name}
          className="group flex shrink-0 items-center gap-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-electric-500"
        >
          <motion.span whileHover={reduceMotion ? undefined : { rotate: -6, scale: 1.06 }} transition={{ type: 'spring', stiffness: 340, damping: 18 }} className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric-600 text-xs font-extrabold tracking-wider text-white shadow-sm transition-colors duration-200 group-hover:bg-electric-500">
            MA
          </motion.span>
          <span className="hidden text-sm font-bold tracking-tight text-slate-900 transition-colors group-hover:text-electric-600 min-[360px]:inline dark:text-white dark:group-hover:text-electric-400">
            {name}
          </span>
        </Link>

        <nav
          aria-label={t('nav.mainLabel')}
          className={`hidden shrink-0 items-center gap-1 whitespace-nowrap ${desktopNavBreakpoint}`}
        >
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) =>
                `group relative whitespace-nowrap rounded-lg px-3 py-2 text-xs font-medium transition-colors duration-200 ${
                  isActive
                    ? 'font-semibold text-electric-700 dark:text-electric-300'
                    : 'text-slate-600 hover:text-electric-700 dark:text-slate-400 dark:hover:text-electric-300'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <span>{t(item.key)}</span>
                  {isActive && (
                    <motion.span
                      layoutId="active-nav-underline"
                      transition={reduceMotion ? { duration: 0 } : { type: 'spring', stiffness: 420, damping: 34 }}
                      className="absolute inset-x-3 bottom-0 h-0.5 origin-center rounded-full bg-gradient-to-r from-electric-500 to-sky-400"
                      aria-hidden="true"
                    />
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="flex shrink-0 items-center gap-2">
          <DownloadCVButton variant="nav" className="hidden sm:inline-flex" />
          <LanguageSwitcher />
          <ThemeToggle />

          <motion.button
            type="button"
            onClick={() => setMobileOpen((o) => !o)}
            aria-expanded={mobileOpen}
            aria-controls="site-mobile-navigation"
            aria-label={mobileOpen ? t('nav.closeMenu') : t('nav.menu')}
            className={`inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white/80 text-slate-700 ${mobileNavBreakpoint} dark:border-slate-800 dark:bg-slate-900/80 dark:text-slate-200`}
            whileHover={reduceMotion ? undefined : { y: -2 }}
            whileTap={reduceMotion ? undefined : { scale: 0.94 }}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </motion.button>
        </div>
      </div>

      <AnimatePresence initial={false}>
      {mobileOpen && (
        <motion.div id="site-mobile-navigation" initial={reduceMotion ? false : { height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: reduceMotion ? 0.12 : 0.22, ease: [0.22, 1, 0.36, 1] }} className={`overflow-hidden border-t border-slate-200/80 bg-white/95 px-4 pt-2 pb-5 backdrop-blur-md ${mobileNavBreakpoint} dark:border-slate-800/80 dark:bg-slate-950/95`}>
          <nav aria-label={t('nav.mobileLabel')} className="flex flex-col gap-1">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.path === '/'}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  `rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-electric-50 text-electric-700 font-semibold dark:bg-electric-950/70 dark:text-electric-300'
                      : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-900'
                  }`
                }
              >
                {t(item.key)}
              </NavLink>
            ))}
          </nav>
          <div className="mt-3 pt-3 border-t border-slate-200/70 dark:border-slate-800/70">
            <DownloadCVButton variant="nav" className="w-full justify-center" />
          </div>
        </motion.div>
      )}
      </AnimatePresence>
    </header>
  );
}
