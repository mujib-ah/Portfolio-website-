import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Globe } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function LanguageSwitcher({ className = '' }) {
  const { language, toggleLanguage, t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const next = language === 'en' ? 'دری' : 'EN';
  const nextFull = language === 'en' ? 'دری (Dari)' : 'English';

  return (
    <motion.button
      type="button"
      onClick={toggleLanguage}
      aria-label={t('actions.langSwitch')}
      title={nextFull}
      className={`inline-flex h-10 items-center gap-1.5 overflow-hidden rounded-xl border border-slate-200 bg-white/80 px-3 text-xs font-semibold text-slate-700 shadow-sm backdrop-blur transition-all duration-300 hover:border-electric-400 hover:text-electric-600 focus:outline-none focus:ring-2 focus:ring-electric-500/50 dark:border-slate-800 dark:bg-slate-900/80 dark:text-slate-200 dark:hover:border-electric-500 dark:hover:text-electric-400 ${className}`}
      whileHover={reduceMotion ? undefined : { y: -2 }}
      whileTap={reduceMotion ? undefined : { scale: 0.95 }}
    >
      <Globe className="h-4 w-4 shrink-0 text-electric-500" />
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={next}
          initial={reduceMotion ? false : { opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -5 }}
          transition={{ duration: reduceMotion ? 0.12 : 0.18 }}
          className="tracking-wide"
        >
          {next}
        </motion.span>
      </AnimatePresence>
    </motion.button>
  );
}
