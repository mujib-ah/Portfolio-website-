import { motion, useReducedMotion, useScroll, useSpring } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

export default function ScrollProgress() {
  const { isRTL } = useLanguage();
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const smooth = useSpring(scrollYProgress, { stiffness: 120, damping: 28, restDelta: 0.001 });

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none fixed inset-x-0 top-0 z-[45] h-[3px] bg-gradient-to-r from-electric-500 via-sky-400 to-indigo-400"
      style={{ scaleX: reduceMotion ? scrollYProgress : smooth, originX: isRTL ? 1 : 0 }}
    />
  );
}
