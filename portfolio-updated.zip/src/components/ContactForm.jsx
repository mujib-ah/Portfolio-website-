import { useState } from 'react';
import { Send, CheckCircle2, AlertTriangle, Mail, Copy, Check, Info } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import siteConfig from '../config/site';

const initialForm = { name: '', email: '', subject: '', message: '' };
const initialBot = false;

export default function ContactForm() {
  const { t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const [botcheck, setBotcheck] = useState(initialBot);

  const validate = () => {
    const err = {};
    if (!form.name.trim()) err.name = t('contact.validationErrors.nameRequired');
    if (!form.email.trim()) err.email = t('contact.validationErrors.emailRequired');
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) err.email = t('contact.validationErrors.emailInvalid');
    if (!form.subject.trim()) err.subject = t('contact.validationErrors.subjectRequired');
    if (!form.message.trim()) err.message = t('contact.validationErrors.messageRequired');
    else if (form.message.trim().length < 10) err.message = t('contact.validationErrors.messageTooShort');
    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    if (errors[name]) setErrors((previous) => ({ ...previous, [name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    const endpoint = siteConfig.contactService.endpoint?.trim();
    if (!endpoint) {
      setStatus('unconfigured');
      return;
    }

    setStatus('submitting');
    setErrorMsg('');
    try {
      const isWeb3 = siteConfig.contactService.service === 'web3forms';
      const body = isWeb3
        ? JSON.stringify({
            access_key: siteConfig.contactService.accessKey,
            from_name: 'Portfolio Contact Form',
            botcheck,
            ...form,
            subject: `[Portfolio] ${form.subject}`,
          })
        : JSON.stringify(form);
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body,
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || (isWeb3 && result.success !== true)) {
        throw new Error(result.message || `HTTP ${response.status}`);
      }
      setStatus('success');
      setForm(initialForm);
    } catch (error) {
      setErrorMsg(error.message || 'Network error');
      setStatus('error');
    }
  };

  const mailtoHref = `mailto:${siteConfig.social.email}?subject=${encodeURIComponent(form.subject || 'Portfolio Inquiry')}&body=${encodeURIComponent(`From: ${form.name}\nEmail: ${form.email}\n\n${form.message}`)}`;

  const copyDetails = async () => {
    const text = `Name: ${form.name}\nEmail: ${form.email}\nSubject: ${form.subject}\nMessage: ${form.message}`;
    try {
      await navigator.clipboard?.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const inputClass = (field) => `mt-1.5 w-full rounded-xl border bg-slate-50/80 px-4 py-3 text-sm text-slate-900 placeholder-slate-400 shadow-inner shadow-slate-900/[0.015] transition-all duration-200 focus:bg-white focus:outline-none focus:ring-4 dark:bg-slate-950/70 dark:text-white dark:placeholder-slate-600 dark:focus:bg-slate-950 ${errors[field] ? 'border-rose-400 focus:ring-rose-400/15' : 'border-slate-200 focus:border-electric-500 focus:ring-electric-500/10 dark:border-slate-800'}`;

  return (
    <motion.div initial={reduceMotion ? false : { opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.12 }} transition={{ duration: reduceMotion ? 0.12 : 0.55, ease: [0.22, 1, 0.36, 1] }} className="rounded-3xl border border-white/80 bg-white/80 p-6 shadow-[0_28px_80px_-42px_rgba(15,23,42,0.32)] backdrop-blur-xl sm:p-8 dark:border-slate-800/90 dark:bg-slate-900/85">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">{t('contact.formTitle')}</h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{t('contact.requiredHint')}</p>
        </div>
        <a href={`mailto:${siteConfig.social.email}`} className="inline-flex items-center gap-2 rounded-xl border border-electric-200/80 bg-electric-50/70 px-3 py-2 text-xs font-semibold text-electric-800 transition-all hover:-translate-y-0.5 hover:border-electric-300 hover:bg-white hover:shadow-md dark:border-electric-900/70 dark:bg-electric-950/40 dark:text-electric-300 dark:hover:bg-slate-900">
          <Mail className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">{siteConfig.social.email}</span>
          <span className="sm:hidden">{t('contact.openEmailClient')}</span>
        </a>
      </div>

      {status === 'success' && <motion.div role="status" aria-live="polite" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="mt-6 flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-xs text-emerald-900 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-300"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /><p>{t('contact.statusSuccess')}</p></motion.div>}
      {status === 'error' && <motion.div role="alert" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="mt-6 flex items-start gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-xs text-rose-900 dark:border-rose-900/60 dark:bg-rose-950/40 dark:text-rose-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" /><p>{t('contact.statusError')} {errorMsg && <span className="block pt-1 opacity-75">{errorMsg}</span>}</p></motion.div>}
      {status === 'unconfigured' && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="mt-6 rounded-2xl border border-electric-200 bg-electric-50/70 p-4 text-xs text-slate-700 dark:border-electric-900/60 dark:bg-electric-950/30 dark:text-slate-300">
          <div className="flex items-start gap-2.5"><Info className="mt-0.5 h-4 w-4 shrink-0 text-electric-600 dark:text-electric-400" /><div><p className="font-semibold text-slate-900 dark:text-white">{t('contact.statusUnconfiguredTitle')}</p><p className="mt-1">{t('contact.statusUnconfigured')}</p></div></div>
          <div className="mt-4 flex flex-wrap gap-2">
            <a href={mailtoHref} className="inline-flex items-center gap-1.5 rounded-xl bg-electric-600 px-3.5 py-2 text-xs font-semibold text-white transition-all hover:-translate-y-0.5 hover:bg-electric-500"><Mail className="h-3.5 w-3.5" />{t('contact.openEmailClient')}</a>
            <button type="button" onClick={copyDetails} className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">{copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}{copied ? t('actions.emailCopied') : t('contact.copyMessageDetails')}</button>
          </div>
        </motion.div>
      )}

      <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-4">
        <input type="checkbox" name="botcheck" checked={botcheck} onChange={(e) => setBotcheck(e.target.checked)} tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />
        {[
          { name: 'name', label: t('contact.nameLabel'), placeholder: t('contact.namePlaceholder'), type: 'text' },
          { name: 'email', label: t('contact.emailFieldLabel'), placeholder: t('contact.emailPlaceholder'), type: 'email' },
          { name: 'subject', label: t('contact.subjectLabel'), placeholder: t('contact.subjectPlaceholder'), type: 'text' },
        ].map((field) => (
          <div key={field.name}>
            <label htmlFor={field.name} className="block text-xs font-semibold text-slate-700 dark:text-slate-300">{field.label} <span className="text-electric-500">*</span></label>
            <motion.input whileFocus={reduceMotion ? undefined : { scale: 1.003 }} id={field.name} name={field.name} type={field.type} value={form[field.name]} onChange={handleChange} placeholder={field.placeholder} className={inputClass(field.name)} aria-invalid={Boolean(errors[field.name])} aria-describedby={errors[field.name] ? `${field.name}-error` : undefined} />
            {errors[field.name] && <p id={`${field.name}-error`} className="mt-1 text-xs text-rose-500">{errors[field.name]}</p>}
          </div>
        ))}
        <div>
          <label htmlFor="message" className="block text-xs font-semibold text-slate-700 dark:text-slate-300">{t('contact.messageLabel')} <span className="text-electric-500">*</span></label>
          <textarea id="message" name="message" rows={5} value={form.message} onChange={handleChange} placeholder={t('contact.messagePlaceholder')} className={inputClass('message')} aria-invalid={Boolean(errors.message)} aria-describedby={errors.message ? 'message-error' : undefined} />
          {errors.message && <p id="message-error" className="mt-1 text-xs text-rose-500">{errors.message}</p>}
        </div>
        <motion.button type="submit" disabled={status === 'submitting'} whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.99 }} className="btn-shine inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-electric-600 to-blue-600 px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_30px_-12px_rgba(14,127,231,0.7)] transition-all duration-200 hover:from-electric-500 hover:to-blue-500 disabled:opacity-60">
          <Send className="h-4 w-4" /><span>{status === 'submitting' ? `${t('contact.sendButton')}...` : t('contact.sendButton')}</span>
        </motion.button>
      </form>
    </motion.div>
  );
}
