import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';

export default function ThemeToggle({ className = '' }) {
  const { theme, toggleTheme } = useTheme();
  const { t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const isDark = theme === 'dark';
  const Icon = isDark ? Moon : Sun;

  return (
    <motion.button
      type="button"
      onClick={toggleTheme}
      aria-label={isDark ? t('actions.themeLight') : t('actions.themeDark')}
      title={isDark ? t('actions.themeLight') : t('actions.themeDark')}
      className={`relative inline-flex h-10 w-10 items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-white/80 text-slate-700 shadow-sm backdrop-blur transition-all duration-300 hover:border-electric-400 hover:text-electric-600 focus:outline-none focus:ring-2 focus:ring-electric-500/50 dark:border-slate-800 dark:bg-slate-900/80 dark:text-slate-200 dark:hover:border-electric-500 dark:hover:text-electric-400 ${className}`}
      whileHover={reduceMotion ? undefined : { y: -2, rotate: isDark ? -6 : 6 }}
      whileTap={reduceMotion ? undefined : { scale: 0.92 }}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={theme}
          initial={reduceMotion ? false : { opacity: 0, scale: 0.65, rotate: -35 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          exit={{ opacity: 0, scale: 0.65, rotate: 35 }}
          transition={{ duration: reduceMotion ? 0.12 : 0.2 }}
          className="inline-flex"
        >
          <Icon className="h-5 w-5" />
        </motion.span>
      </AnimatePresence>
    </motion.button>
  );
}
