import { useEffect, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowUp } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function BackToTop() {
  const { t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 520);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          key="back-to-top"
          type="button"
          aria-label={t('common.backToTop')}
          title={t('common.backToTop')}
          onClick={() => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' })}
          initial={{ opacity: 0, y: 18, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 18, scale: 0.8 }}
          whileHover={reduceMotion ? undefined : { y: -3, scale: 1.06 }}
          whileTap={reduceMotion ? undefined : { scale: 0.92 }}
          transition={{ type: 'spring', stiffness: 340, damping: 24 }}
          className="fixed bottom-5 end-5 z-40 flex h-11 w-11 items-center justify-center rounded-full bg-electric-600 text-white shadow-glow transition-colors hover:bg-electric-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-300 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-950 sm:bottom-6 sm:end-6"
        >
          <ArrowUp className="h-5 w-5" aria-hidden="true" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
