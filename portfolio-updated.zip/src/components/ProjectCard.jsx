import { useState } from 'react';
import { ExternalLink, Sparkles, AlertCircle } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

const entrance = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } },
};

export default function ProjectCard({ project, wide = false }) {
  const { language, t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const [tip, setTip] = useState(null);

  const name = language === 'da' ? project.nameDari || project.name : project.name;
  const category = language === 'da' ? project.categoryDari || project.category : project.category;
  const description = project.description?.[language] || project.description?.en || '';
  const highlights = project.highlights?.[language] || project.highlights?.en || [];
  const alt = language === 'da' ? project.imageAltDari : project.imageAlt;

  const showTip = (key) => {
    setTip(key);
    setTimeout(() => setTip((current) => (current === key ? null : current)), 3000);
  };

  return (
    <motion.article
      variants={entrance}
      initial={reduceMotion ? false : 'hidden'}
      whileInView="visible"
      viewport={{ once: true, amount: 0.14 }}
      whileHover={reduceMotion ? undefined : { y: -7, scale: 1.008 }}
      transition={{ type: 'spring', stiffness: 270, damping: 25 }}
      className={`spotlight group overflow-hidden rounded-3xl border border-slate-200/90 bg-white/95 shadow-[0_16px_50px_-34px_rgba(15,23,42,0.42)] backdrop-blur transition-[border-color,box-shadow] duration-300 hover:border-electric-300 hover:shadow-[0_30px_70px_-38px_rgba(14,127,231,0.48)] dark:border-slate-800 dark:bg-slate-900/90 dark:hover:border-electric-800 ${wide ? 'lg:grid lg:grid-cols-[minmax(0,0.88fr)_minmax(0,1.12fr)]' : ''}`}
    >
      <div className={`relative aspect-video w-full overflow-hidden bg-gradient-to-br from-slate-100 via-electric-50/50 to-slate-200 dark:from-slate-900 dark:via-electric-950/40 dark:to-slate-950 ${wide ? 'lg:aspect-auto lg:min-h-[28rem]' : ''}`}>
        {project.image ? (
          <motion.img src={project.image} alt={alt || name} className={`h-full w-full object-cover object-top ${wide ? 'lg:absolute lg:inset-0' : ''}`} loading="lazy" whileHover={reduceMotion ? undefined : { scale: 1.055 }} transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }} />
        ) : (
          <div className={`flex h-full w-full flex-col items-center justify-center p-6 text-center select-none ${wide ? 'lg:min-h-[28rem]' : ''}`}>
            <div aria-hidden="true" className="absolute inset-0 opacity-35 [background-image:radial-gradient(circle_at_1px_1px,#0e7fe7_1px,transparent_0)] [background-size:22px_22px] transition-transform duration-700 group-hover:scale-105" />
            <motion.div whileHover={reduceMotion ? undefined : { rotate: 6, scale: 1.06 }} className="relative z-10 flex h-16 w-16 items-center justify-center rounded-2xl border border-white/70 bg-white/90 text-electric-600 shadow-xl shadow-electric-900/10 backdrop-blur dark:border-slate-700 dark:bg-slate-900/90 dark:text-electric-400"><Sparkles className="h-7 w-7" /></motion.div>
            <p className="relative z-10 mt-4 text-xs font-semibold text-slate-600 dark:text-slate-300">{t('projects.previewTitle')}</p>
            <p className="relative z-10 mt-1 text-[11px] text-slate-400 dark:text-slate-500">{t('projects.previewHint')}</p>
          </div>
        )}
        {project.featured && <span className="absolute top-4 start-4 inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-electric-600/95 px-3 py-1.5 text-[11px] font-semibold text-white shadow-lg shadow-electric-900/15 backdrop-blur"><Sparkles className="h-3 w-3" />{t('projects.featuredBadge')}</span>}
        {project.year && <span className="absolute top-4 end-4 rounded-full border border-white/20 bg-slate-950/65 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur">{project.year}</span>}
      </div>

      <div className={`p-6 sm:p-7 ${wide ? 'lg:p-9' : ''}`}>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-electric-600 dark:text-electric-400">{category}</p>
        <h3 className="mt-2 text-xl font-bold tracking-tight text-slate-900 transition-colors group-hover:text-electric-700 dark:text-white dark:group-hover:text-electric-300">{name}</h3>
        <p className="mt-3 text-sm leading-7 text-slate-600 dark:text-slate-400">{description}</p>

        {highlights.length > 0 && <ul className="mt-4 space-y-2 text-xs text-slate-500 dark:text-slate-400">{highlights.map((highlight, index) => <li key={index} className="flex items-start gap-2.5"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-electric-500" /><span>{highlight}</span></li>)}</ul>}

        <div className="mt-5 flex flex-wrap gap-2">
          {project.technologies.map((technology) => <span key={technology} className="rounded-full border border-slate-200/90 bg-slate-50 px-3 py-1.5 text-[11px] font-semibold text-slate-600 transition-colors hover:border-electric-200 hover:text-electric-700 dark:border-slate-700 dark:bg-slate-800/75 dark:text-slate-300 dark:hover:border-electric-800 dark:hover:text-electric-300">{technology}</span>)}
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-5 dark:border-slate-800">
          {project.liveUrl ? (
            <motion.a href={project.liveUrl} target="_blank" rel="noreferrer" whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.97 }} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-electric-600 to-blue-600 px-4 py-2.5 text-xs font-semibold text-white shadow-md shadow-electric-600/20 transition-shadow hover:shadow-lg hover:shadow-electric-600/30"><ExternalLink className="h-3.5 w-3.5" />{t('actions.liveDemo')}</motion.a>
          ) : (
            <motion.button type="button" onClick={() => showTip('demo')} whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.97 }} className="inline-flex items-center gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-2.5 text-xs font-semibold text-slate-500 transition-colors hover:border-electric-300 hover:text-electric-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-400 dark:hover:border-electric-800 dark:hover:text-electric-300"><ExternalLink className="h-3.5 w-3.5" />{t('actions.liveDemo')}</motion.button>
          )}
          {project.githubUrl ? (
            <motion.a href={project.githubUrl} target="_blank" rel="noreferrer" whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.97 }} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 transition-all hover:border-electric-200 hover:bg-electric-50/60 hover:text-electric-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-electric-900 dark:hover:bg-electric-950/30 dark:hover:text-electric-300"><i className="fa-brands fa-github text-sm" aria-hidden="true" />{t('actions.viewCode')}</motion.a>
          ) : (
            <motion.button type="button" onClick={() => showTip('code')} whileHover={reduceMotion ? undefined : { y: -2 }} whileTap={reduceMotion ? undefined : { scale: 0.97 }} className="inline-flex items-center gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-2.5 text-xs font-semibold text-slate-500 transition-colors hover:border-electric-300 hover:text-electric-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-400 dark:hover:border-electric-800 dark:hover:text-electric-300"><i className="fa-brands fa-github text-sm" aria-hidden="true" />{t('actions.viewCode')}</motion.button>
          )}
        </div>

        {tip && <motion.p initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="mt-3 flex items-center gap-1.5 text-[11px] text-amber-600 dark:text-amber-400"><AlertCircle className="h-3 w-3" />{tip === 'demo' ? t('projects.liveUnavailable') : t('projects.codeUnavailable')}</motion.p>}
      </div>
    </motion.article>
  );
}
