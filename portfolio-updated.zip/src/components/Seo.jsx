import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import siteConfig from '../config/site';
import seoPages, { notFoundSeo } from '../config/seo';

function setMeta(attr, key, value) {
  let el = document.head.querySelector(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', value);
}

function setCanonical(href) {
  let el = document.head.querySelector('link[rel="canonical"]');
  if (!href) {
    el?.remove();
    return;
  }
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', 'canonical');
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

export default function Seo() {
  const { pathname } = useLocation();
  const { language } = useLanguage();

  useEffect(() => {
    const lang = language === 'da' ? 'da' : 'en';
    const page = seoPages[pathname];
    const { title, description } = (page ? page[lang] : notFoundSeo[lang]);
    const base = (siteConfig.siteUrl || '').replace(/\/$/, '');
    const url = base ? `${base}${pathname === '/' ? '/' : pathname}` : '';

    document.title = title;
    setMeta('name', 'description', description);
    setMeta('property', 'og:title', title);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:locale', lang === 'da' ? 'fa_AF' : 'en_US');
    setMeta('name', 'twitter:title', title);
    setMeta('name', 'twitter:description', description);
    if (url) setMeta('property', 'og:url', url);
    setCanonical(page ? url : '');
    setMeta('name', 'robots', page ? 'index, follow' : 'noindex, follow');
  }, [pathname, language]);

  return null;
}
