import { Link } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import DownloadCVButton from './DownloadCVButton';
import HomeHeroVisual from './HomeHeroVisual';
import siteConfig from '../config/site';

export default function HeroSection() {
  const { t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const reveal = reduceMotion
    ? { hidden: { opacity: 1, y: 0 }, visible: { opacity: 1, y: 0, transition: { duration: 0 } } }
    : { hidden: { opacity: 0, y: 18 }, visible: { opacity: 1, y: 0, transition: { duration: 0.56, ease: [0.22, 1, 0.36, 1] } } };
  const introStagger = {
    hidden: {},
    visible: { transition: { staggerChildren: reduceMotion ? 0 : 0.11, delayChildren: reduceMotion ? 0 : 0.08 } },
  };
  const actionStagger = {
    hidden: {},
    visible: { transition: { staggerChildren: reduceMotion ? 0 : 0.1, delayChildren: reduceMotion ? 0 : 0.34 } },
  };
  const name = t('hero.name');
  const role = t('hero.role');

  return (
    <section className="relative isolate overflow-hidden pb-12 pt-8 sm:pb-14 sm:pt-12 lg:pb-14 lg:pt-12">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 opacity-50 [background-image:linear-gradient(rgba(100,116,139,0.055)_1px,transparent_1px),linear-gradient(90deg,rgba(100,116,139,0.055)_1px,transparent_1px)] [background-size:64px_64px] [mask-image:radial-gradient(ellipse_at_center,black_15%,transparent_76%)] dark:opacity-30" />
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute -top-48 start-1/2 -z-10 h-[32rem] w-[32rem] -translate-x-1/2 rounded-full bg-electric-500/10 blur-3xl sm:h-[42rem] sm:w-[42rem] dark:bg-electric-500/15"
        animate={reduceMotion ? undefined : { scale: [1, 1.06, 1], opacity: [0.55, 0.8, 0.55] }}
        transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
      />

      <div className="relative mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-y-6 px-4 sm:gap-y-8 sm:px-6 min-[950px]:grid-cols-[1.1fr_0.9fr] min-[950px]:gap-x-6 min-[950px]:gap-y-0 lg:px-8 xl:gap-x-10">
        <motion.div
          className="min-w-0 space-y-5 min-[950px]:col-start-1 min-[950px]:row-start-1 min-[950px]:py-3"
          initial="hidden"
          animate="visible"
          variants={introStagger}
        >
          <motion.div variants={reveal} className="inline-flex items-center gap-2 rounded-full border border-electric-200/80 bg-white/70 px-3.5 py-1.5 text-xs font-semibold text-electric-700 shadow-sm backdrop-blur dark:border-electric-900/60 dark:bg-slate-900/70 dark:text-electric-300">
            <span className="relative flex h-2 w-2" aria-hidden="true">
              <span className={`absolute inline-flex h-full w-full rounded-full bg-electric-400 opacity-60 ${reduceMotion ? '' : 'animate-ping'}`} />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-electric-500" />
            </span>
            <span>{t('hero.badge')}</span>
          </motion.div>

          <motion.div variants={reveal}>
            <p className="text-xs font-bold uppercase tracking-[0.22em] text-slate-500 dark:text-slate-400">{t('hero.greeting')}</p>
            <h1 className="mt-3 max-w-full bg-gradient-to-r from-slate-950 via-slate-800 to-slate-600 bg-clip-text text-5xl font-black leading-[1.03] tracking-[-0.055em] text-transparent sm:text-6xl lg:text-[3.75rem] xl:text-[4.25rem] dark:from-white dark:via-slate-100 dark:to-slate-400">
              {name}
            </h1>
            <div className="mt-5 flex items-center gap-3">
              <span className="h-px w-8 shrink-0 bg-gradient-to-r from-electric-500 to-sky-400" aria-hidden="true" />
              <p className="text-base font-semibold tracking-tight text-electric-700 sm:text-xl dark:text-electric-300">{role}</p>
            </div>
          </motion.div>

          <motion.p variants={reveal} className="max-w-2xl text-base leading-7 text-slate-600 sm:text-[17px] sm:leading-8 dark:text-slate-300">
            {t('hero.intro')}
          </motion.p>
        </motion.div>

        <div className="relative min-w-0 w-full min-[950px]:col-start-2 min-[950px]:row-start-1 min-[950px]:row-span-2 min-[950px]:flex min-[950px]:items-center">
          <HomeHeroVisual />
        </div>

        <motion.div
          className="min-w-0 space-y-4 min-[950px]:col-start-1 min-[950px]:row-start-2 min-[950px]:pt-1"
          initial="hidden"
          animate="visible"
          variants={actionStagger}
        >
          <motion.div variants={reveal} className="flex flex-wrap items-center gap-3">
            <DownloadCVButton variant="hero" />
            <motion.div whileHover={reduceMotion ? undefined : { y: -3 }} whileTap={reduceMotion ? undefined : { scale: 0.98 }} transition={{ type: 'spring', stiffness: 360, damping: 22 }}>
              <Link to="/contact" className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300/90 bg-white/80 px-5 py-3 text-sm font-semibold text-slate-800 shadow-sm backdrop-blur transition-all duration-200 hover:border-electric-400 hover:bg-white hover:shadow-lg hover:shadow-electric-500/10 dark:border-slate-700 dark:bg-slate-900/75 dark:text-slate-100 dark:hover:border-electric-500 dark:hover:bg-slate-900">
                <Mail className="h-4 w-4" />
                <span>{t('actions.contactMe')}</span>
              </Link>
            </motion.div>
          </motion.div>

          <motion.div variants={reveal} className="flex items-center gap-3 pt-1 text-xs text-slate-500 dark:text-slate-400">
            <span className="me-1 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">{t('footer.connectTitle')}</span>
            <motion.a href={siteConfig.social.github} target="_blank" rel="noreferrer" aria-label="GitHub" whileHover={reduceMotion ? undefined : { y: -3 }} whileTap={reduceMotion ? undefined : { scale: 0.94 }} className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200/90 bg-white/70 text-slate-600 shadow-sm transition-colors hover:border-electric-400 hover:text-electric-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 dark:border-slate-800 dark:bg-slate-900/70 dark:text-slate-400 dark:hover:border-electric-500 dark:hover:text-electric-400">
              <i className="fa-brands fa-github text-sm" aria-hidden="true" />
            </motion.a>
            <motion.a href={siteConfig.social.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn" whileHover={reduceMotion ? undefined : { y: -3 }} whileTap={reduceMotion ? undefined : { scale: 0.94 }} className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200/90 bg-white/70 text-slate-600 shadow-sm transition-colors hover:border-electric-400 hover:text-electric-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 dark:border-slate-800 dark:bg-slate-900/70 dark:text-slate-400 dark:hover:border-electric-500 dark:hover:text-electric-400">
              <i className="fa-brands fa-linkedin text-sm" aria-hidden="true" />
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
