import { Download } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import siteConfig from '../config/site';

export default function DownloadCVButton({ variant = 'nav', className = '' }) {
  const { t } = useLanguage();
  const reduceMotion = useReducedMotion();
  const { enabled, file } = siteConfig.cv;

  if (!enabled || !file) return null;

  const isNav = variant === 'nav';

  return (
    <motion.a
      href={file}
      download={siteConfig.cv.downloadName || file.split('/').pop()}
      title={t('actions.downloadCV')}
      whileHover={reduceMotion ? undefined : { y: -2 }}
      whileTap={reduceMotion ? undefined : { scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 360, damping: 22 }}
      className={
        isNav
          ? `inline-flex h-10 items-center gap-1.5 rounded-xl border border-electric-500/50 bg-electric-50/70 px-3.5 text-xs font-semibold text-electric-700 shadow-sm transition-all duration-200 hover:bg-electric-500 hover:text-white dark:border-electric-500/40 dark:bg-electric-950/60 dark:text-electric-300 dark:hover:bg-electric-600 dark:hover:text-white ${className}`
          : `btn-shine inline-flex items-center justify-center gap-2 rounded-xl bg-electric-600 px-5 py-3 text-sm font-semibold text-white shadow-glow transition-all duration-200 hover:bg-electric-500 hover:shadow-glow-lg focus:outline-none focus:ring-2 focus:ring-electric-500 focus:ring-offset-2 dark:focus:ring-offset-slate-950 ${className}`
      }
    >
      <Download className={isNav ? 'h-3.5 w-3.5' : 'h-4 w-4'} />
      <span>{t('actions.downloadCV')}</span>
    </motion.a>
  );
}
