import { useEffect, useRef, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import ScrollToTop from './ScrollToTop';
import LoadingScreen from './LoadingScreen';
import PageLoader from './PageLoader';
import Seo from './Seo';
import ScrollProgress from './ScrollProgress';
import BackToTop from './BackToTop';
import siteConfig from '../config/site';
import { useLanguage } from '../context/LanguageContext';

const LOADED_KEY = 'mujiport_loaded';

const NAVIGATE_AT = 350;
const FADE_OUT_AT = 900;
const DONE_AT = 1250;

const ROUTE_LABELS = {
  '/': 'nav.home',
  '/about': 'nav.about',
  '/skills': 'nav.skills',
  '/projects': 'nav.projects',
  '/experience': 'nav.experience',
  '/education': 'nav.education',
  '/contact': 'nav.contact',
};

const isPlainLeftClick = (e) =>
  e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;

export default function Layout({ children }) {
  const location = useLocation();
  const navigate = useNavigate();
  const reduceMotion = useReducedMotion();
  const { t } = useLanguage();
  const mainRef = useRef(null);
  const firstRender = useRef(true);
  const [pageLoad, setPageLoad] = useState(null);
  const timers = useRef([]);
  const [loading, setLoading] = useState(() => {
    if (!siteConfig.loadingScreen.enabled) return false;
    try {
      return !sessionStorage.getItem(LOADED_KEY);
    } catch {
      return true;
    }
  });

  const handleFinish = () => {
    try {
      sessionStorage.setItem(LOADED_KEY, '1');
    } catch {}
    setLoading(false);
  };

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    mainRef.current?.focus({ preventScroll: true });
  }, [location.pathname]);

  const goTo = (path, labelKey) => {
    if (path === location.pathname) return;
    if (reduceMotion) {
      navigate(path);
      return;
    }
    timers.current.forEach(clearTimeout);
    setPageLoad({ labelKey, phase: 'in' });
    timers.current = [
      setTimeout(() => navigate(path), NAVIGATE_AT),
      setTimeout(() => setPageLoad((p) => (p ? { ...p, phase: 'out' } : p)), FADE_OUT_AT),
      setTimeout(() => setPageLoad(null), DONE_AT),
    ];
  };

  const handleClickCapture = (e) => {
    if (!isPlainLeftClick(e) || e.defaultPrevented || pageLoad?.phase === 'in') return;
    const anchor = e.target.closest?.('a[href]');
    if (!anchor || anchor.target === '_blank' || anchor.hasAttribute('download')) return;
    let url;
    try {
      url = new URL(anchor.href, window.location.href);
    } catch {
      return;
    }
    if (url.origin !== window.location.origin) return;
    const labelKey = ROUTE_LABELS[url.pathname];
    if (!labelKey || url.pathname === location.pathname) return;
    e.preventDefault();
    goTo(url.pathname, labelKey);
  };

  const handlePointerMove = (e) => {
    if (e.pointerType !== 'mouse') return;
    const card = e.target.closest?.('.spotlight');
    if (!card) return;
    const rect = card.getBoundingClientRect();
    card.style.setProperty('--mx', `${e.clientX - rect.left}px`);
    card.style.setProperty('--my', `${e.clientY - rect.top}px`);
  };

  return (
    <div className="flex min-h-screen flex-col" onClickCapture={handleClickCapture} onPointerMove={handlePointerMove}>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-electric-600 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white focus:shadow-glow"
      >
        {t('common.skipToContent')}
      </a>
      <Seo />
      <ScrollProgress />
      <ScrollToTop />
      {loading && <LoadingScreen onFinish={handleFinish} />}
      <Navbar />
      <main id="main-content" ref={mainRef} tabIndex={-1} className="flex-1 focus:outline-none">
        <motion.div
          key={location.pathname}
          initial={reduceMotion ? false : { opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: reduceMotion ? 0.12 : 0.28, ease: [0.22, 1, 0.36, 1] }}
          className="min-h-full"
        >
          {children}
        </motion.div>
      </main>
      <Footer />
      <BackToTop />
      {pageLoad && <PageLoader phase={pageLoad.phase} labelKey={pageLoad.labelKey} duration={FADE_OUT_AT} />}
    </div>
  );
}
