import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

export default function PageLoader({ phase, labelKey, duration }) {
  const { t } = useLanguage();
  const label = `${t('loading.opening')} ${t(labelKey)}…`;

  return (
    <motion.div
      role="status"
      aria-live="polite"
      initial={{ opacity: 0 }}
      animate={{ opacity: phase === 'in' ? 1 : 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-white/90 backdrop-blur-md dark:bg-slate-950/92 ${
        phase === 'in' ? '' : 'pointer-events-none'
      }`}
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute h-80 w-80 rounded-full bg-electric-500/15 blur-3xl"
      />
      <div className="relative flex flex-col items-center px-4 text-center">
        <motion.div
          className="flex h-14 w-14 items-center justify-center rounded-2xl bg-electric-600 text-sm font-extrabold tracking-widest text-white shadow-glow"
          animate={{ scale: [1, 1.07, 1] }}
          transition={{ duration: 1, repeat: Infinity, ease: 'easeInOut' }}
        >
          MA
        </motion.div>
        <p className="mt-5 text-sm font-semibold text-slate-700 dark:text-slate-200">{label}</p>
        <div className="mt-4 h-0.5 w-40 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
          <motion.div
            className="h-full origin-left rounded-full bg-gradient-to-r from-electric-500 to-sky-400"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: duration / 1000, ease: 'easeInOut' }}
          />
        </div>
      </div>
    </motion.div>
  );
}
