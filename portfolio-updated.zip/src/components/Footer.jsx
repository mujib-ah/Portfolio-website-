import { Link } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import siteConfig from '../config/site';

const navItems = [
  { path: '/', key: 'nav.home' },
  { path: '/about', key: 'nav.about' },
  { path: '/skills', key: 'nav.skills' },
  { path: '/projects', key: 'nav.projects' },
  { path: '/experience', key: 'nav.experience' },
  { path: '/education', key: 'nav.education' },
  { path: '/contact', key: 'nav.contact' },
];

export default function Footer() {
  const { t, language } = useLanguage();
  const githubUrl = siteConfig.social.github;
  const year = new Date().getFullYear();
  const name = language === 'da' ? siteConfig.nameDari : siteConfig.name;

  return (
    <footer className="mt-auto border-t border-slate-200/80 bg-white/75 py-12 backdrop-blur-xl transition-colors duration-500 dark:border-slate-800/80 dark:bg-slate-950/75">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-12">
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-electric-500 to-blue-700 text-xs font-extrabold tracking-wider text-white shadow-md shadow-electric-700/20">
                MA
              </span>
              <span className="text-base font-bold text-slate-900 dark:text-white">
                {name}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm leading-relaxed">
              {t('footer.tagline')}
            </p>
            <a href={`mailto:${siteConfig.social.email}`} className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 transition-colors hover:text-electric-600 dark:text-slate-400 dark:hover:text-electric-300">
              <Mail className="h-3.5 w-3.5 text-electric-500" />
              {siteConfig.social.email}
            </a>
          </div>

          <div className="md:col-span-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t('footer.navTitle')}
            </p>
            <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-xs">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className="text-slate-600 transition-colors duration-200 hover:text-electric-600 dark:text-slate-400 dark:hover:text-electric-400"
                  >
                    {t(item.key)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              {t('footer.connectTitle')}
            </p>
            <div className="mt-3 flex items-center gap-2">
              <a
                href={githubUrl}
                target="_blank"
                rel="noreferrer"
                aria-label={t('actions.github')}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:border-electric-400 hover:text-electric-600 transition-colors dark:border-slate-800 dark:text-slate-400 dark:hover:border-electric-500 dark:hover:text-electric-400"
              >
                <i className="fa-brands fa-github text-sm" aria-hidden="true" />
              </a>
              <a
                href={siteConfig.social.linkedin}
                target="_blank"
                rel="noreferrer"
                aria-label={t('actions.linkedin')}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:border-electric-400 hover:text-electric-600 transition-colors dark:border-slate-800 dark:text-slate-400 dark:hover:border-electric-500 dark:hover:text-electric-400"
              >
                <i className="fa-brands fa-linkedin text-sm" aria-hidden="true" />
              </a>
              <Link
                to="/contact"
                aria-label={t('actions.contactMe')}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:border-electric-400 hover:text-electric-600 transition-colors dark:border-slate-800 dark:text-slate-400 dark:hover:border-electric-500 dark:hover:text-electric-400"
              >
                <Mail className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-slate-200/70 pt-6 text-[11px] text-slate-400 sm:flex-row dark:border-slate-800/70 dark:text-slate-500">
          <p>
            © {year} {name}. {t('footer.rights')}
          </p>
          <p>{t('footer.builtWith')}</p>
        </div>
      </div>
    </footer>
  );
}
