import skills from '../data/skills';

export default function TechMarquee() {
  const items = [...skills, ...skills];

  return (
    <div aria-hidden="true" dir="ltr" className="relative overflow-hidden py-5 [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
      <div className="flex w-max animate-marquee hover:[animation-play-state:paused] motion-reduce:animate-none">
        {items.map((skill, index) => (
          <span
            key={`${skill.id}-${index}`}
            className="mr-3 inline-flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/80 px-4 py-2 text-xs font-semibold text-slate-600 shadow-sm backdrop-blur-sm transition-colors duration-200 hover:border-electric-300 hover:text-electric-700 dark:border-slate-800 dark:bg-slate-900/80 dark:text-slate-300 dark:hover:border-electric-700 dark:hover:text-electric-300"
          >
            <i className={skill.faIcon} style={{ color: skill.color }} />
            {skill.name}
          </span>
        ))}
      </div>
    </div>
  );
}
