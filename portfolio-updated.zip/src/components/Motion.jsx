import { motion, useReducedMotion } from 'framer-motion';

const easeOut = [0.22, 1, 0.36, 1];

export function Reveal({ children, className = '', delay = 0, distance = 18, as = 'div', ...props }) {
  const shouldReduceMotion = useReducedMotion();
  const Component = motion[as] || motion.div;

  return (
    <Component
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0, y: distance }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.16, margin: '0px 0px -36px 0px' }}
      transition={{ duration: shouldReduceMotion ? 0.15 : 0.58, delay: shouldReduceMotion ? 0 : delay, ease: easeOut }}
      {...props}
    >
      {children}
    </Component>
  );
}

export function Stagger({ children, className = '', delay = 0.07, ...props }) {
  const shouldReduceMotion = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={shouldReduceMotion ? 'visible' : 'hidden'}
      whileInView="visible"
      viewport={{ once: true, amount: 0.14, margin: '0px 0px -32px 0px' }}
      variants={{
        hidden: {},
        visible: { transition: { staggerChildren: shouldReduceMotion ? 0 : delay } },
      }}
      {...props}
    >
      {children}
    </motion.div>
  );
}

export const staggerItem = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: easeOut } },
};
