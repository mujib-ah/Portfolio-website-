import { motion, useReducedMotion } from 'framer-motion';
import { ArrowUpRight, Code2, ExternalLink, Layers3 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

function safeExternalUrl(value) {
  if (!value) return null;
  try {
    const parsed = new URL(value);
    return ['http:', 'https:'].includes(parsed.protocol) ? parsed.href : null;
  } catch {
    return null;
  }
}

export default function HomeFeaturedProject({ project }) {
  const { t, language } = useLanguage();
  const reduceMotion = useReducedMotion();
  if (!project) return null;

  const name = language === 'da' ? project.nameDari || project.name : project.name;
  const category = language === 'da' ? project.categoryDari || project.category : project.category;
  const description = project.description?.[language] || project.description?.en || '';
  const imageAlt = language === 'da' ? project.imageAltDari || name : project.imageAlt || name;
  const liveUrl = safeExternalUrl(project.liveUrl);
  const codeUrl = safeExternalUrl(project.githubUrl);

  return (
    <motion.article
      initial={reduceMotion ? false : { opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.18 }}
      transition={{ duration: reduceMotion ? 0.15 : 0.56, ease: [0.22, 1, 0.36, 1] }}
      whileHover={reduceMotion ? undefined : { y: -5, scale: 1.003 }}
      className="spotlight group relative overflow-hidden rounded-[28px] border border-slate-200/90 bg-white/90 shadow-[0_24px_70px_-48px_rgba(15,23,42,0.45)] backdrop-blur transition-[border-color,box-shadow] duration-300 hover:border-electric-300 hover:shadow-[0_32px_80px_-42px_rgba(14,127,231,0.28)] dark:border-slate-800 dark:bg-slate-900/90 dark:hover:border-electric-800"
    >
      <div aria-hidden="true" className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-electric-500 via-sky-400 to-indigo-500" />

      <div className={`grid ${project.image ? 'lg:grid-cols-[1.05fr_0.95fr]' : 'lg:grid-cols-[1fr_0.78fr]'}`}>
        <div className="p-6 sm:p-8 lg:p-10">
          <div className="flex flex-wrap items-center gap-2">
            {project.featured && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-electric-50 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-electric-700 dark:bg-electric-950/60 dark:text-electric-300">
                <Layers3 className="h-3.5 w-3.5" aria-hidden="true" />
                {t('projects.featuredBadge')}
              </span>
            )}
            <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">{category}</span>
          </div>

          <h3 className="mt-5 text-2xl font-extrabold tracking-tight text-slate-950 transition-colors group-hover:text-electric-700 sm:text-3xl dark:text-white dark:group-hover:text-electric-300">
            {name}
          </h3>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-600 sm:text-[15px] dark:text-slate-400">{description}</p>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            {liveUrl && (
              <motion.a
                href={liveUrl}
                target="_blank"
                rel="noreferrer"
                whileHover={reduceMotion ? undefined : { y: -2 }}
                whileTap={reduceMotion ? undefined : { scale: 0.98 }}
                className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-electric-600 px-4 py-2.5 text-xs font-semibold text-white shadow-glow transition-colors hover:bg-electric-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 focus-visible:ring-offset-2"
              >
                <ExternalLink className="h-4 w-4" aria-hidden="true" />
                {t('actions.liveDemo')}
              </motion.a>
            )}
            {codeUrl && (
              <motion.a
                href={codeUrl}
                target="_blank"
                rel="noreferrer"
                whileHover={reduceMotion ? undefined : { y: -2 }}
                whileTap={reduceMotion ? undefined : { scale: 0.98 }}
                className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 transition-colors hover:border-electric-300 hover:text-electric-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 focus-visible:ring-offset-2 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-electric-700 dark:hover:text-electric-300"
              >
                <i className="fa-brands fa-github text-sm" aria-hidden="true" />
                {t('actions.viewCode')}
              </motion.a>
            )}
            <Link
              to="/projects"
              className="inline-flex min-h-11 items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-semibold text-electric-700 transition-colors hover:text-electric-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-500 dark:text-electric-300 dark:hover:text-electric-200"
            >
              {t('actions.allProjects')}
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        </div>

        <div className="border-t border-slate-100 bg-slate-50/75 p-5 dark:border-slate-800 dark:bg-slate-950/35 lg:border-t-0 lg:border-s lg:p-7">
          {project.image ? (
            <motion.div
              className="relative h-full min-h-[240px] overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-900"
              whileHover={reduceMotion ? undefined : { scale: 1.012 }}
              transition={{ duration: 0.35 }}
            >
              <motion.img
                src={project.image}
                alt={imageAlt}
                loading="lazy"
                className="h-full min-h-[240px] w-full object-cover object-top"
                whileHover={reduceMotion ? undefined : { scale: 1.045 }}
                transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
              />
            </motion.div>
          ) : (
            <div className="flex h-full min-h-[220px] flex-col justify-between rounded-2xl border border-slate-200/80 bg-white/85 p-5 dark:border-slate-800 dark:bg-slate-900/70 sm:min-h-[250px] sm:p-6">
              <div className="flex items-center justify-between gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-electric-50 text-electric-600 dark:bg-electric-950/70 dark:text-electric-300">
                  <Code2 className="h-5 w-5" aria-hidden="true" />
                </span>
                <span className="text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400 dark:text-slate-500">{t('projects.techLabel')}</span>
              </div>
              <div className="mt-8">
                <div aria-hidden="true" className="h-px bg-gradient-to-r from-electric-400/60 via-sky-300/40 to-transparent" />
                <div className="mt-4 flex flex-wrap gap-2">
                  {(project.technologies || []).map((technology) => (
                    <motion.span
                      key={technology}
                      className="rounded-xl border border-electric-100 bg-electric-50/75 px-3 py-2 text-xs font-semibold text-electric-800 dark:border-electric-900/60 dark:bg-electric-950/40 dark:text-electric-200"
                      whileHover={reduceMotion ? undefined : { y: -2 }}
                      transition={{ duration: 0.18 }}
                    >
                      {technology}
                    </motion.span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.article>
  );
}
